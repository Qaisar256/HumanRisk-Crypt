"""Utility functions for reproducibility."""
from __future__ import annotations

import os
import random
import numpy as np


def set_seed(seed: int = 42) -> None:
    """Set Python and NumPy random seeds."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
