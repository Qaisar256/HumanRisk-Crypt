"""BFV backends used by HumanRisk-Crypt.

Paper experiments require :class:`TenSEALBFVContext`. The mock backend is
restricted to unit tests and interface demonstrations and is never selected by
paper experiment scripts.
"""
from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Any, Protocol, runtime_checkable
import warnings

import numpy as np


@dataclass(frozen=True)
class BFVParameters:
    polynomial_modulus_degree: int = 8192
    coefficient_modulus_bits: tuple[int, ...] = (54, 54, 55, 55)  # total 218 bits
    plaintext_modulus: int = 65537

    @property
    def coefficient_modulus_total_bits(self) -> int:
        return int(sum(self.coefficient_modulus_bits))

    @property
    def batching_slots(self) -> int:
        return self.polynomial_modulus_degree

    @property
    def centered_plaintext_limit(self) -> int:
        return (self.plaintext_modulus - 1) // 2


@dataclass
class CryptoTiming:
    encode_encrypt_ms: float = 0.0
    serialize_request_ms: float = 0.0
    deserialize_request_ms: float = 0.0
    homomorphic_eval_ms: float = 0.0
    serialize_response_ms: float = 0.0
    deserialize_response_ms: float = 0.0
    decrypt_ms: float = 0.0
    request_bytes: int = 0
    response_bytes: int = 0
    noise_budget_before_bits: int | None = None
    noise_budget_after_bits: int | None = None

    @property
    def total_ms(self) -> float:
        return float(
            self.encode_encrypt_ms
            + self.serialize_request_ms
            + self.deserialize_request_ms
            + self.homomorphic_eval_ms
            + self.serialize_response_ms
            + self.deserialize_response_ms
            + self.decrypt_ms
        )


@runtime_checkable
class BFVCiphertext(Protocol):
    def serialize(self) -> bytes: ...


class TenSEALUnavailableError(RuntimeError):
    pass


class TenSEALBFVContext:
    """Real BFV backend implemented with TenSEAL/Microsoft SEAL.

    The client context contains the secret key. ``public_context_bytes`` creates
    a server context without it, preserving only the public and evaluation keys.
    """

    cryptographic = True
    backend_name = "tenseal-bfv"

    def __init__(self, params: BFVParameters | None = None, context: Any | None = None) -> None:
        self.params = params or BFVParameters()
        try:
            import tenseal as ts
        except ImportError as exc:
            raise TenSEALUnavailableError(
                "TenSEAL is required for paper experiments. Install the pinned "
                "crypto environment or use the supplied Dockerfile."
            ) from exc
        self.ts = ts
        if context is None:
            self.context = ts.context(
                ts.SCHEME_TYPE.BFV,
                poly_modulus_degree=self.params.polynomial_modulus_degree,
                plain_modulus=self.params.plaintext_modulus,
                coeff_mod_bit_sizes=list(self.params.coefficient_modulus_bits),
            )
            # Dot products require rotations; ciphertext multiplication requires
            # relinearization keys. Generate both explicitly so the serialized
            # public context contains every evaluation key used by the server.
            if not self.context.has_relin_keys():
                self.context.generate_relin_keys()
            if not self.context.has_galois_keys():
                self.context.generate_galois_keys()
        else:
            self.context = context

    def public_context_bytes(self) -> bytes:
        return self.context.serialize(
            save_public_key=True,
            save_secret_key=False,
            save_galois_keys=True,
            save_relin_keys=True,
        )

    @classmethod
    def from_public_context_bytes(cls, blob: bytes, params: BFVParameters | None = None) -> "TenSEALBFVContext":
        try:
            import tenseal as ts
        except ImportError as exc:
            raise TenSEALUnavailableError("TenSEAL is required to load a BFV context.") from exc
        return cls(params=params, context=ts.context_from(blob))

    def encrypt_vector(self, values: np.ndarray | list[int]):
        array = np.asarray(values, dtype=np.int64).reshape(-1)
        if array.size > self.params.batching_slots:
            raise ValueError(
                f"Vector has {array.size} values but BFV context supports "
                f"{self.params.batching_slots} batching slots."
            )
        return self.ts.bfv_vector(self.context, array.tolist())

    def decrypt_vector(self, ciphertext) -> np.ndarray:
        return np.asarray(ciphertext.decrypt(), dtype=np.int64)

    def serialize_ciphertext(self, ciphertext) -> bytes:
        return ciphertext.serialize()

    def deserialize_ciphertext(self, blob: bytes):
        return self.ts.bfv_vector_from(self.context, blob)

    def noise_budget_bits(self, ciphertext) -> int | None:
        """Return SEAL invariant noise budget when exposed by this TenSEAL build.

        TenSEAL wheels differ in how much of the underlying SEAL API they expose.
        A missing value is recorded as unavailable, never fabricated.
        """
        try:
            raw_ct = ciphertext.ciphertext()[0]
            decryptor = self.context.decryptor()
            native_decryptor = getattr(decryptor, "data", decryptor)
            return int(native_decryptor.invariant_noise_budget(raw_ct))
        except Exception:
            return None

    def verify_roundtrip(self, values: np.ndarray | list[int]) -> bool:
        expected = np.asarray(values, dtype=np.int64).reshape(-1)
        observed = self.decrypt_vector(self.encrypt_vector(expected))[: expected.size]
        return bool(np.array_equal(expected, observed))


@dataclass
class MockCiphertext:
    value: np.ndarray

    def serialize(self) -> bytes:
        return np.asarray(self.value, dtype=np.int64).tobytes()

    def dot(self, other) -> "MockCiphertext":
        return MockCiphertext(np.asarray([int(self.value @ np.asarray(other, dtype=np.int64))], dtype=np.int64))

    def __mul__(self, other) -> "MockCiphertext":
        other_value = other.value if isinstance(other, MockCiphertext) else other
        return MockCiphertext(self.value * np.asarray(other_value, dtype=np.int64))

    def __add__(self, other) -> "MockCiphertext":
        other_value = other.value if isinstance(other, MockCiphertext) else other
        return MockCiphertext(self.value + np.asarray(other_value, dtype=np.int64))

    __radd__ = __add__


class MockBFVContext:
    """Non-cryptographic backend for unit tests and smoke demos only."""

    cryptographic = False
    backend_name = "mock-bfv-non-cryptographic"

    def __init__(self, params: BFVParameters | None = None) -> None:
        self.params = params or BFVParameters()
        warnings.warn(
            "MockBFVContext does not provide cryptographic security and must not "
            "be used for paper results.",
            RuntimeWarning,
            stacklevel=2,
        )

    def public_context_bytes(self) -> bytes:
        return b"mock-public-context"

    def encrypt_vector(self, values: np.ndarray | list[int]) -> MockCiphertext:
        return MockCiphertext(np.asarray(values, dtype=np.int64).reshape(-1).copy())

    def decrypt_vector(self, ciphertext: MockCiphertext) -> np.ndarray:
        if not isinstance(ciphertext, MockCiphertext):
            raise TypeError("Expected MockCiphertext")
        return ciphertext.value.copy()

    def serialize_ciphertext(self, ciphertext: MockCiphertext) -> bytes:
        return ciphertext.serialize()

    def deserialize_ciphertext(self, blob: bytes) -> MockCiphertext:
        return MockCiphertext(np.frombuffer(blob, dtype=np.int64).copy())

    def noise_budget_bits(self, ciphertext: MockCiphertext) -> None:
        return None

    def verify_roundtrip(self, values: np.ndarray | list[int]) -> bool:
        expected = np.asarray(values, dtype=np.int64).reshape(-1)
        return bool(np.array_equal(expected, self.decrypt_vector(self.encrypt_vector(expected))))


def timed_call(fn, *args, **kwargs):
    start = perf_counter()
    result = fn(*args, **kwargs)
    return result, (perf_counter() - start) * 1000.0
