"""BFV compatible encryption interface.

The default backend is a mock implementation for reproducible testing without
Microsoft SEAL. It preserves the same call structure but is not cryptographic.
Replace MockBFVContext with a real SEAL/TenSEAL wrapper for secure experiments.
"""
from __future__ import annotations

from dataclasses import dataclass
import time
import numpy as np


@dataclass
class BFVParameters:
    polynomial_modulus_degree: int = 8192
    coefficient_modulus_bits: int = 218
    plaintext_modulus: int = 65537

    @property
    def theoretical_ciphertext_size_bytes(self) -> int:
        return int(2 * self.polynomial_modulus_degree * self.coefficient_modulus_bits / 8)

    @property
    def seal_aligned_ciphertext_size_bytes(self) -> int:
        limbs = int(np.ceil(self.coefficient_modulus_bits / 64))
        return int(2 * self.polynomial_modulus_degree * limbs * 8)


@dataclass
class MockCiphertext:
    """Development only ciphertext container."""
    value: np.ndarray
    encrypted: bool = True


class MockBFVContext:
    """Mock BFV interface for unit tests and demos.

    This class intentionally does not encrypt data. It allows the rest of the
    pipeline to be executed without SEAL bindings.
    """

    def __init__(self, params: BFVParameters | None = None) -> None:
        self.params = params or BFVParameters()

    def encode(self, vector: np.ndarray) -> np.ndarray:
        return np.asarray(vector, dtype=np.int64)

    def encrypt(self, plaintext: np.ndarray) -> MockCiphertext:
        return MockCiphertext(np.asarray(plaintext, dtype=np.float64))

    def decrypt(self, ciphertext: MockCiphertext) -> np.ndarray:
        if not isinstance(ciphertext, MockCiphertext):
            raise TypeError("Expected MockCiphertext.")
        return np.asarray(ciphertext.value)

    def add(self, a: MockCiphertext, b: MockCiphertext | float | np.ndarray) -> MockCiphertext:
        b_val = b.value if isinstance(b, MockCiphertext) else b
        return MockCiphertext(a.value + b_val)

    def multiply(self, a: MockCiphertext, b: MockCiphertext | float | np.ndarray) -> MockCiphertext:
        b_val = b.value if isinstance(b, MockCiphertext) else b
        return MockCiphertext(a.value * b_val)

    def matmul(self, matrix: np.ndarray, ciphertext: MockCiphertext, bias: np.ndarray | None = None) -> MockCiphertext:
        out = np.asarray(ciphertext.value) @ np.asarray(matrix).T
        if bias is not None:
            out = out + bias
        return MockCiphertext(out)


def time_call(fn, *args, **kwargs):
    start = time.perf_counter()
    result = fn(*args, **kwargs)
    elapsed_ms = (time.perf_counter() - start) * 1000
    return result, elapsed_ms
