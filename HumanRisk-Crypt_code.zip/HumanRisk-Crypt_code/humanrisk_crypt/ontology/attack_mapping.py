"""ATT&CK aligned ontology mapping for phishing indicators."""
from __future__ import annotations

import numpy as np
import pandas as pd


ATTACK_TECHNIQUES = {
    "T1566.002": "Spearphishing Link",
    "T1556": "Modify Authentication Process / Credential Harvesting",
    "T1204": "User Execution",
    "T1598": "Phishing for Information",
    "T1110": "Brute Force Indicators",
}


class AttackTechniqueMapper:
    """Map behavioral and persuasion indicators into ATT&CK technique labels."""

    def map_records(self, df: pd.DataFrame, phishing_prob: np.ndarray) -> list[dict[str, float | str]]:
        outputs = []
        for _, row in df.iterrows():
            urgency = float(row.get("urgency_score", 0.0))
            authority = float(row.get("authority_score", 0.0))
            domain_age = float(row.get("domain_age_days", 365.0))
            brand = str(row.get("brand", "none"))
            prob = float(phishing_prob[len(outputs)])

            if prob < 0.5:
                technique = "Benign"
                score = 0.0
            elif domain_age < 30 and brand != "none":
                technique = "T1566.002"
                score = 0.85
            elif authority > 0.65:
                technique = "T1556"
                score = 0.80
            elif urgency > 0.70:
                technique = "T1204"
                score = 0.75
            else:
                technique = "T1598"
                score = 0.65

            outputs.append({
                "attack_id": technique,
                "attack_name": ATTACK_TECHNIQUES.get(technique, "Benign"),
                "mapping_score": score,
            })
        return outputs
