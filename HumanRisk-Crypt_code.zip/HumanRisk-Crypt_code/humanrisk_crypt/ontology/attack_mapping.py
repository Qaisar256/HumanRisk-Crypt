"""RDFLib-backed ATT&CK-aligned phishing interpretation.

This module provides ontology-backed querying, not a claim of automated ATT&CK
attribution. Observable indicators are converted to evidence nodes and queried
against an RDF graph containing the supported phishing techniques.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd

ATTACK_TECHNIQUES = {
    "T1566.002": "Spearphishing Link",
    "T1556": "Modify Authentication Process",
    "T1204": "User Execution",
    "T1598": "Phishing for Information",
}


@dataclass(frozen=True)
class MappingResult:
    attack_id: str
    attack_name: str
    mapping_score: float
    evidence: tuple[str, ...]


class AttackTechniqueMapper:
    def __init__(self) -> None:
        try:
            from rdflib import Graph, Literal, Namespace, RDF
        except ImportError as exc:
            raise RuntimeError("rdflib is required for ontology-backed ATT&CK mapping") from exc
        self.Graph, self.Literal, self.Namespace, self.RDF = Graph, Literal, Namespace, RDF
        self.EX = Namespace("https://humanrisk-crypt.example/ontology/")
        self.graph = Graph()
        self.graph.bind("hrc", self.EX)
        self._build_graph()

    def _build_graph(self) -> None:
        technique_type = self.EX.Technique
        indicator_type = self.EX.Indicator
        supports = self.EX.supportsTechnique
        for attack_id, name in ATTACK_TECHNIQUES.items():
            node = self.EX[f"attack/{attack_id}"]
            self.graph.add((node, self.RDF.type, technique_type))
            self.graph.add((node, self.EX.attackId, self.Literal(attack_id)))
            self.graph.add((node, self.EX.name, self.Literal(name)))
        associations = {
            "young_branded_domain": "T1566.002",
            "credential_authority_pressure": "T1556",
            "urgent_user_action": "T1204",
            "information_request": "T1598",
        }
        for indicator, attack_id in associations.items():
            inode = self.EX[f"indicator/{indicator}"]
            tnode = self.EX[f"attack/{attack_id}"]
            self.graph.add((inode, self.RDF.type, indicator_type))
            self.graph.add((inode, supports, tnode))

    def _lookup(self, indicator: str) -> tuple[str, str]:
        indicator_uri = self.EX[f"indicator/{indicator}"]
        query = f"""
        PREFIX hrc: <{self.EX}>
        SELECT ?attackId ?name WHERE {{
          <{indicator_uri}> hrc:supportsTechnique ?technique .
          ?technique hrc:attackId ?attackId ; hrc:name ?name .
        }}
        """
        rows = list(self.graph.query(query))
        if len(rows) != 1:
            raise RuntimeError(f"Ontology query returned {len(rows)} rows for {indicator}")
        return str(rows[0].attackId), str(rows[0].name)

    def map_records(self, df: pd.DataFrame, phishing_prob: np.ndarray) -> list[dict[str, object]]:
        outputs: list[dict[str, object]] = []
        for pos, (_, row) in enumerate(df.iterrows()):
            prob = float(phishing_prob[pos])
            if prob < 0.5:
                outputs.append(
                    MappingResult("Benign", "Benign", 0.0, ("probability_below_threshold",)).__dict__
                )
                continue
            evidence: list[str] = []
            domain_age = float(row.get("domain_age_days", 365))
            brand = str(row.get("brand", "none")).lower()
            authority = float(row.get("authority_score", 0.0))
            urgency = float(row.get("urgency_score", 0.0))
            if domain_age < 30 and brand not in {"", "none", "unknown"}:
                indicator, score = "young_branded_domain", 0.85
                evidence.extend(["domain_age_days<30", "brand_impersonation"])
            elif authority >= 0.65:
                indicator, score = "credential_authority_pressure", 0.80
                evidence.append("authority_score>=0.65")
            elif urgency >= 0.70:
                indicator, score = "urgent_user_action", 0.75
                evidence.append("urgency_score>=0.70")
            else:
                indicator, score = "information_request", 0.65
                evidence.append("phishing_probability>=0.50")
            attack_id, name = self._lookup(indicator)
            outputs.append(MappingResult(attack_id, name, score, tuple(evidence)).__dict__)
        return outputs
