"""Expert-calibrated Human Vulnerability Severity Scoring."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge


COMPONENT_COLUMNS = [
    "urgency_score",
    "authority_score",
    "reward_score",
    "fear_score",
    "hosting_stability",
]


@dataclass
class EHVSSCalibrationReport:
    samples: int
    experts: int | None
    alpha: float
    training_mae: float


class EHVSSScorer:
    """Calibrate risk scores against expert-provided 0 to 10 ratings.

    ``fit`` is required for paper mode. ``use_demo_heuristic=True`` is explicit
    and intended only for smoke tests.
    """

    def __init__(self, alpha: float = 1.0, use_demo_heuristic: bool = False) -> None:
        self.alpha = alpha
        self.use_demo_heuristic = use_demo_heuristic
        self.model = Ridge(alpha=alpha, positive=True)
        self.fitted = False
        self.report: EHVSSCalibrationReport | None = None

    def _matrix(self, df: pd.DataFrame, phishing_prob: np.ndarray) -> np.ndarray:
        cols = []
        for name in COMPONENT_COLUMNS:
            default = 0.5 if name == "hosting_stability" else 0.0
            values = pd.to_numeric(df.get(name, default), errors="coerce").fillna(default)
            cols.append(np.clip(values.to_numpy(dtype=float), 0.0, 1.0))
        cols.append(np.clip(np.asarray(phishing_prob, dtype=float), 0.0, 1.0))
        cols.append(1.0 - cols[4])
        return np.column_stack(cols)

    def fit(
        self,
        df: pd.DataFrame,
        phishing_prob: np.ndarray,
        expert_scores: np.ndarray,
        expert_ids: np.ndarray | None = None,
    ) -> "EHVSSScorer":
        scores = np.asarray(expert_scores, dtype=float).reshape(-1)
        if len(scores) != len(df):
            raise ValueError("expert_scores must align with dataframe rows")
        if np.any((scores < 0) | (scores > 10)):
            raise ValueError("Expert E-HVSS scores must be within [0, 10]")
        x = self._matrix(df, phishing_prob)
        self.model.fit(x, scores)
        pred = np.clip(self.model.predict(x), 0, 10)
        self.fitted = True
        experts = int(len(np.unique(expert_ids))) if expert_ids is not None else None
        self.report = EHVSSCalibrationReport(
            samples=len(scores),
            experts=experts,
            alpha=self.alpha,
            training_mae=float(np.mean(np.abs(pred - scores))),
        )
        return self

    def score(self, df: pd.DataFrame, phishing_prob: np.ndarray) -> np.ndarray:
        x = self._matrix(df, phishing_prob)
        if self.fitted:
            return np.round(np.clip(self.model.predict(x), 0, 10), 3)
        if not self.use_demo_heuristic:
            raise RuntimeError(
                "E-HVSS is not calibrated. Provide expert scores and call fit(), "
                "or explicitly enable the demo heuristic for smoke testing."
            )
        urgency, authority, reward, fear, stability, prob, instability = x.T
        demo = 10 * np.clip(
            0.18 * urgency
            + 0.16 * authority
            + 0.10 * reward
            + 0.16 * fear
            + 0.20 * prob
            + 0.20 * instability,
            0,
            1,
        )
        return np.round(demo, 3)

    @staticmethod
    def risk_label(scores: np.ndarray) -> np.ndarray:
        bins = np.digitize(np.asarray(scores), [4.0, 7.0, 9.0], right=False)
        return np.asarray(["Low", "Medium", "High", "Critical"])[bins]

    def save(self, path: str | Path) -> None:
        if not self.fitted:
            raise RuntimeError("Cannot save an uncalibrated scorer")
        payload = {
            "alpha": self.alpha,
            "coef": self.model.coef_.tolist(),
            "intercept": float(self.model.intercept_),
            "report": self.report.__dict__ if self.report else None,
        }
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")
