"""Encrypted Human Vulnerability Scoring System."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd


@dataclass
class EHVSSWeights:
    susceptibility: float = 0.25
    exploitability: float = 0.30
    detectability: float = 0.20
    impact: float = 0.25


class EHVSSScorer:
    """Compute E-HVSS scores from feature tables and phishing probability."""

    def __init__(self, weights: EHVSSWeights | None = None) -> None:
        self.weights = weights or EHVSSWeights()

    @staticmethod
    def _clip01(x):
        return np.clip(np.asarray(x, dtype=float), 0.0, 1.0)

    def component_scores(self, df: pd.DataFrame, phishing_prob: np.ndarray) -> dict[str, np.ndarray]:
        urgency = self._clip01(df.get("urgency_score", 0.0))
        authority = self._clip01(df.get("authority_score", 0.0))
        reward = self._clip01(df.get("reward_score", 0.0))
        fear = self._clip01(df.get("fear_score", 0.0))
        domain_age = np.asarray(df.get("domain_age_days", 365), dtype=float)
        hosting_stability = self._clip01(df.get("hosting_stability", 0.5))

        susceptibility = self._clip01(0.35 * urgency + 0.25 * authority + 0.20 * fear + 0.20 * reward)
        exploitability = self._clip01(0.60 * (domain_age < 30).astype(float) + 0.40 * (1 - hosting_stability))
        detectability = self._clip01(1 - phishing_prob)
        impact = self._clip01(0.50 * phishing_prob + 0.50 * np.maximum(authority, fear))

        return {
            "susceptibility": susceptibility,
            "exploitability": exploitability,
            "detectability": detectability,
            "impact": impact,
        }

    def score(self, df: pd.DataFrame, phishing_prob: np.ndarray) -> np.ndarray:
        comp = self.component_scores(df, phishing_prob)
        raw = (
            self.weights.susceptibility * comp["susceptibility"]
            + self.weights.exploitability * comp["exploitability"]
            + self.weights.detectability * comp["detectability"]
            + self.weights.impact * comp["impact"]
        )
        return np.round(10 * self._clip01(raw), 3)

    @staticmethod
    def risk_label(scores: np.ndarray) -> np.ndarray:
        labels = []
        for s in scores:
            if s < 4:
                labels.append("Low")
            elif s < 7:
                labels.append("Medium")
            elif s < 9:
                labels.append("High")
            else:
                labels.append("Critical")
        return np.array(labels)

    def encrypted_score(self, bfv, ct_probability, plaintext_df: pd.DataFrame):
        prob = bfv.decrypt(ct_probability)
        score = self.score(plaintext_df, prob)
        return bfv.encrypt(score)
