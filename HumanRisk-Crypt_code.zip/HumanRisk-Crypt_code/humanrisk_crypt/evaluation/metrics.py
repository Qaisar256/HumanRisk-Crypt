"""Evaluation metrics for classification and E-HVSS scoring."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, log_loss, mean_absolute_error
)
from scipy.stats import spearmanr


def classification_report_dict(y_true: np.ndarray, y_prob: np.ndarray, threshold: float = 0.5) -> dict[str, float]:
    y_pred = (y_prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    return {
        "ACC": float(accuracy_score(y_true, y_pred)),
        "PRE": float(precision_score(y_true, y_pred, zero_division=0)),
        "REC": float(recall_score(y_true, y_pred, zero_division=0)),
        "F1": float(f1_score(y_true, y_pred, zero_division=0)),
        "AUC": float(roc_auc_score(y_true, y_prob)),
        "FPR": float(fp / (fp + tn + 1e-12)),
        "FNR": float(fn / (fn + tp + 1e-12)),
        "LogLoss": float(log_loss(y_true, y_prob)),
    }


def hvss_alignment(expert_scores: np.ndarray, predicted_scores: np.ndarray) -> dict[str, float]:
    rho = spearmanr(expert_scores, predicted_scores).correlation
    return {
        "rho": float(rho),
        "MAE": float(mean_absolute_error(expert_scores, predicted_scores)),
    }


def summarize_runs(rows: list[dict[str, float]]) -> dict[str, str]:
    keys = rows[0].keys()
    summary = {}
    for key in keys:
        values = np.array([r[key] for r in rows], dtype=float)
        summary[key] = f"{values.mean():.3f} ± {values.std(ddof=1):.3f}" if len(values) > 1 else f"{values.mean():.3f}"
    return summary
