"""Evaluation metrics."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    log_loss,
    mean_absolute_error,
    precision_score,
    recall_score,
    roc_auc_score,
)
from scipy.stats import spearmanr


def classification_report_dict(y_true: np.ndarray, y_prob: np.ndarray, threshold: float = 0.5) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=int)
    y_prob = np.clip(np.asarray(y_prob, dtype=float), 1e-7, 1 - 1e-7)
    y_pred = (y_prob >= threshold).astype(int)
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = matrix.ravel()
    auc = roc_auc_score(y_true, y_prob) if len(np.unique(y_true)) == 2 else float("nan")
    return {
        "ACC": float(accuracy_score(y_true, y_pred)),
        "PRE": float(precision_score(y_true, y_pred, zero_division=0)),
        "REC": float(recall_score(y_true, y_pred, zero_division=0)),
        "F1": float(f1_score(y_true, y_pred, zero_division=0)),
        "AUC": float(auc),
        "FPR": float(fp / max(fp + tn, 1)),
        "FNR": float(fn / max(fn + tp, 1)),
        "LogLoss": float(log_loss(y_true, y_prob, labels=[0, 1])),
    }


def hvss_alignment(expert_scores: np.ndarray, predicted_scores: np.ndarray) -> dict[str, float]:
    rho = spearmanr(expert_scores, predicted_scores).correlation
    return {
        "rho": float(rho),
        "MAE": float(mean_absolute_error(expert_scores, predicted_scores)),
    }


def summarize_runs(rows: list[dict[str, float]]) -> dict[str, str]:
    if not rows:
        raise ValueError("rows must not be empty")
    summary = {}
    for key in rows[0]:
        values = np.asarray([r[key] for r in rows], dtype=float)
        sd = values.std(ddof=1) if len(values) > 1 else 0.0
        summary[key] = f"{values.mean():.3f} ± {sd:.3f}"
    return summary
