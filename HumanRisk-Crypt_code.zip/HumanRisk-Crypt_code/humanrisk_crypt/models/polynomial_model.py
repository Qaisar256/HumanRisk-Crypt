"""Quadratic polynomial surrogate model for encrypted inference."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss


@dataclass
class PolynomialActivation:
    alpha0: float = 0.0
    alpha1: float = 1.0
    alpha2: float = 0.05

    def __call__(self, x: np.ndarray) -> np.ndarray:
        return self.alpha0 + self.alpha1 * x + self.alpha2 * np.square(x)


class PolynomialSurrogateClassifier:
    """Small BFV-compatible classifier with quadratic feature expansion."""

    def __init__(self, activation: PolynomialActivation | None = None, temperature: float = 1.4) -> None:
        self.activation = activation or PolynomialActivation()
        self.temperature = temperature
        self.classifier = LogisticRegression(max_iter=1000, class_weight="balanced")
        self.fitted = False

    def _expand(self, x: np.ndarray) -> np.ndarray:
        # Quadratic residual nonlinear transformation.
        return np.hstack([x, self.activation(x)])

    def fit(self, x: np.ndarray, y: np.ndarray) -> "PolynomialSurrogateClassifier":
        z = self._expand(x)
        self.classifier.fit(z, y)
        self.fitted = True
        return self

    def logits(self, x: np.ndarray) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("Model must be fitted before inference.")
        z = self._expand(x)
        return z @ self.classifier.coef_[0] + self.classifier.intercept_[0]

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        raw = self.logits(x) / max(self.temperature, 1e-6)
        raw = np.clip(raw, -40, 40)
        prob = 1.0 / (1.0 + np.exp(-raw))
        return np.vstack([1 - prob, prob]).T

    def predict(self, x: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.predict_proba(x)[:, 1] >= threshold).astype(int)

    def encrypted_predict_proba(self, bfv, ct_x):
        # Mock interface: decrypt-free in real HE, mock computes over container values.
        x = ct_x.value
        return bfv.encrypt(self.predict_proba(x)[:, 1])

    def evaluate_log_loss(self, x: np.ndarray, y: np.ndarray) -> float:
        return float(log_loss(y, self.predict_proba(x)[:, 1]))
