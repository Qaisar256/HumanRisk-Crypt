"""PyTorch/AdamW quadratic classifier with exact BFV integer export."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

import numpy as np


@dataclass(frozen=True)
class QuantizedPolynomialParameters:
    linear_weight: np.ndarray
    quadratic_weight: np.ndarray
    bias: int
    feature_scale: int
    weight_scale: int

    def save(self, path: str | Path) -> None:
        np.savez_compressed(
            path,
            linear_weight=self.linear_weight,
            quadratic_weight=self.quadratic_weight,
            bias=np.asarray([self.bias], dtype=np.int64),
            feature_scale=np.asarray([self.feature_scale], dtype=np.int64),
            weight_scale=np.asarray([self.weight_scale], dtype=np.int64),
        )

    @classmethod
    def load(cls, path: str | Path) -> "QuantizedPolynomialParameters":
        data = np.load(path)
        return cls(
            linear_weight=data["linear_weight"].astype(np.int64),
            quadratic_weight=data["quadratic_weight"].astype(np.int64),
            bias=int(data["bias"][0]),
            feature_scale=int(data["feature_scale"][0]),
            weight_scale=int(data["weight_scale"][0]),
        )


class PolynomialSurrogateClassifier:
    """Elementwise quadratic logit trained with PyTorch and AdamW.

    The server evaluates only the integer polynomial logit under BFV. The client
    decrypts the logit and applies sigmoid. No encrypted sigmoid is claimed.
    """

    def __init__(
        self,
        input_dim: int = 1024,
        feature_scale: int = 8,
        weight_scale: int = 32,
        learning_rate: float = 2e-3,
        weight_decay: float = 1e-4,
        epochs: int = 120,
        batch_size: int = 128,
        seed: int = 42,
    ) -> None:
        self.input_dim = input_dim
        self.feature_scale = feature_scale
        self.weight_scale = weight_scale
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.epochs = epochs
        self.batch_size = batch_size
        self.seed = seed
        self.fitted = False
        self.training_history: list[dict[str, float]] = []
        self._linear: np.ndarray | None = None
        self._quadratic: np.ndarray | None = None
        self._bias: float | None = None

    def _quantized_input(self, x: np.ndarray) -> np.ndarray:
        from humanrisk_crypt.data.feature_extraction import quantize_features
        xq = quantize_features(x, scale=self.feature_scale)
        if xq.ndim != 2 or xq.shape[1] != self.input_dim:
            raise ValueError(f"Expected shape (n, {self.input_dim}), got {xq.shape}")
        return xq

    def fit(self, x: np.ndarray, y: np.ndarray) -> "PolynomialSurrogateClassifier":
        import torch
        from torch import nn
        from torch.utils.data import DataLoader, TensorDataset

        torch.manual_seed(self.seed)
        np.random.seed(self.seed)
        xq = self._quantized_input(x).astype(np.float32)
        y = np.asarray(y, dtype=np.float32).reshape(-1, 1)
        if len(np.unique(y)) < 2:
            raise ValueError("Training data must contain both classes")

        class QuadraticLogit(nn.Module):
            def __init__(self, dim: int) -> None:
                super().__init__()
                self.linear_weight = nn.Parameter(torch.zeros(dim))
                self.quadratic_weight = nn.Parameter(torch.zeros(dim))
                self.bias = nn.Parameter(torch.zeros(1))

            def forward(self, inputs):
                return (
                    inputs @ self.linear_weight
                    + (inputs * inputs) @ self.quadratic_weight
                    + self.bias
                ).reshape(-1, 1)

        model = QuadraticLogit(self.input_dim)
        optimizer = torch.optim.AdamW(
            model.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay
        )
        criterion = nn.BCEWithLogitsLoss()
        loader = DataLoader(
            TensorDataset(torch.from_numpy(xq), torch.from_numpy(y)),
            batch_size=min(self.batch_size, len(xq)),
            shuffle=True,
            generator=torch.Generator().manual_seed(self.seed),
        )

        best_loss = float("inf")
        best_state = None
        stale = 0
        for epoch in range(self.epochs):
            model.train()
            running = 0.0
            for batch_x, batch_y in loader:
                optimizer.zero_grad(set_to_none=True)
                loss = criterion(model(batch_x), batch_y)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
                running += float(loss.detach()) * len(batch_x)
            epoch_loss = running / len(xq)
            self.training_history.append({"epoch": float(epoch + 1), "loss": epoch_loss})
            if epoch_loss < best_loss - 1e-5:
                best_loss = epoch_loss
                best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
                stale = 0
            else:
                stale += 1
            if stale >= 15:
                break
        if best_state is not None:
            model.load_state_dict(best_state)

        self._linear = model.linear_weight.detach().cpu().numpy().astype(np.float64)
        self._quadratic = model.quadratic_weight.detach().cpu().numpy().astype(np.float64)
        self._bias = float(model.bias.detach().cpu().item())
        self.fitted = True
        return self

    def _check(self) -> None:
        if not self.fitted or self._linear is None or self._quadratic is None or self._bias is None:
            raise RuntimeError("Model must be fitted before inference")

    def logits(self, x: np.ndarray) -> np.ndarray:
        self._check()
        xq = self._quantized_input(x).astype(np.float64)
        return xq @ self._linear + (xq * xq) @ self._quadratic + self._bias

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        logits = np.clip(self.logits(x), -40, 40)
        prob = 1.0 / (1.0 + np.exp(-logits))
        return np.column_stack([1.0 - prob, prob])

    def predict(self, x: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.predict_proba(x)[:, 1] >= threshold).astype(int)

    def export_quantized(self) -> QuantizedPolynomialParameters:
        self._check()
        return QuantizedPolynomialParameters(
            linear_weight=np.rint(self._linear * self.weight_scale).astype(np.int64),
            quadratic_weight=np.rint(self._quadratic * self.weight_scale).astype(np.int64),
            bias=int(round(self._bias * self.weight_scale)),
            feature_scale=self.feature_scale,
            weight_scale=self.weight_scale,
        )

    @staticmethod
    def plaintext_integer_logit(x_int: np.ndarray, params: QuantizedPolynomialParameters) -> int:
        x_int = np.asarray(x_int, dtype=np.int64).reshape(-1)
        return int(
            x_int @ params.linear_weight
            + (x_int * x_int) @ params.quadratic_weight
            + params.bias
        )

    @staticmethod
    def encrypted_integer_logit(ciphertext, params: QuantizedPolynomialParameters):
        linear = ciphertext.dot(params.linear_weight.tolist())
        squared = ciphertext * ciphertext
        quadratic = squared.dot(params.quadratic_weight.tolist())
        return linear + quadratic + int(params.bias)

    @staticmethod
    def probability_from_integer_logit(logit_integer: int, weight_scale: int) -> float:
        logit = np.clip(float(logit_integer) / float(weight_scale), -40.0, 40.0)
        return float(1.0 / (1.0 + np.exp(-logit)))

    @staticmethod
    def arithmetic_bound(x_int: np.ndarray, params: QuantizedPolynomialParameters) -> int:
        x = np.abs(np.asarray(x_int, dtype=np.int64).reshape(-1))
        return int(
            x @ np.abs(params.linear_weight)
            + (x * x) @ np.abs(params.quadratic_weight)
            + abs(params.bias)
        )

    def save_training_metadata(self, path: str | Path) -> None:
        payload = {
            "optimizer": "AdamW",
            "input_dim": self.input_dim,
            "feature_scale": self.feature_scale,
            "weight_scale": self.weight_scale,
            "learning_rate": self.learning_rate,
            "weight_decay": self.weight_decay,
            "epochs_requested": self.epochs,
            "epochs_completed": len(self.training_history),
            "seed": self.seed,
            "history": self.training_history,
        }
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")
