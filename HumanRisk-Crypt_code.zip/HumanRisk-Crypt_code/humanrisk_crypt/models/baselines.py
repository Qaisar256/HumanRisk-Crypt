"""Plaintext baseline evaluation without fabricated encrypted variants."""
from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Callable

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from humanrisk_crypt.data.feature_extraction import FeatureBuilder
from humanrisk_crypt.data.splitting import time_domain_split
from humanrisk_crypt.evaluation.metrics import classification_report_dict


@dataclass(frozen=True)
class BaselineSpec:
    name: str
    factory: Callable[[int], object]


def baseline_specs() -> list[BaselineSpec]:
    return [
        BaselineSpec(
            "Logistic Regression",
            lambda seed: LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed),
        ),
        BaselineSpec(
            "Random Forest",
            lambda seed: RandomForestClassifier(
                n_estimators=300,
                max_depth=16,
                class_weight="balanced",
                random_state=seed,
                n_jobs=-1,
            ),
        ),
        BaselineSpec(
            "Gradient Boosting",
            lambda seed: GradientBoostingClassifier(random_state=seed),
        ),
    ]


def _positive_probability(model, x: np.ndarray) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        return model.predict_proba(x)[:, 1]
    decision = model.decision_function(x)
    return 1.0 / (1.0 + np.exp(-decision))


def run_plaintext_baselines(
    df: pd.DataFrame,
    seeds: list[int] | None = None,
    test_fraction: float = 0.25,
    semantic_backend: str = "sentence_transformer",
    semantic_model: str = "sentence-transformers/distiluse-base-multilingual-cased-v2",
    local_files_only: bool = True,
) -> tuple[pd.DataFrame, dict]:
    seeds = seeds or [42, 123, 2026]
    train_df, test_df, audit = time_domain_split(df, test_fraction=test_fraction)
    features = FeatureBuilder(
        semantic_backend=semantic_backend,
        semantic_model=semantic_model,
        local_files_only=local_files_only,
    )
    x_train = features.fit_transform(train_df)
    x_test = features.transform(test_df)
    y_train = train_df["label"].to_numpy(dtype=int)
    y_test = test_df["label"].to_numpy(dtype=int)

    rows: list[dict] = []
    for seed in seeds:
        for spec in baseline_specs():
            model = spec.factory(seed)
            model.fit(x_train, y_train)
            start = perf_counter()
            probability = _positive_probability(model, x_test)
            latency_ms = (perf_counter() - start) * 1000.0 / len(x_test)
            rows.append(
                {
                    "Model / Method": spec.name,
                    "seed": seed,
                    **classification_report_dict(y_test, probability),
                    "Measured_plaintext_inference_ms": latency_ms,
                }
            )
    return pd.DataFrame(rows), audit.to_dict()


def summarize_comparison(results: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "ACC",
        "PRE",
        "REC",
        "F1",
        "AUC",
        "FPR",
        "FNR",
        "LogLoss",
        "Measured_plaintext_inference_ms",
    ]
    grouped = results.groupby("Model / Method", sort=False)[metrics]
    mean_df = grouped.mean().add_suffix("_mean")
    std_df = grouped.std(ddof=1).add_suffix("_sd")
    return mean_df.join(std_df).reset_index()
