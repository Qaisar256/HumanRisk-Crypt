"""Baseline comparison models for HumanRisk-Crypt.

The classes in this module reproduce the comparison protocol used in the
manuscript. They are intentionally lightweight so they can run on public CSV
files or on the provided synthetic fallback dataset.

Encrypted baselines use the same feature and estimator interfaces, but route
features through the mock BFV encode/encrypt/decrypt boundary. This keeps the
code reproducible without Microsoft SEAL bindings. Replace MockBFVContext with
an actual SEAL wrapper for cryptographic experiments.
"""
from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Callable, Iterable

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

from humanrisk_crypt.crypto.bfv_interface import BFVParameters, MockBFVContext
from humanrisk_crypt.data.feature_extraction import FeatureBuilder, quantize_features
from humanrisk_crypt.evaluation.metrics import classification_report_dict
from humanrisk_crypt.models.polynomial_model import PolynomialSurrogateClassifier
from humanrisk_crypt.utils.seed import set_seed


URL_NUMERIC = [
    "url_length",
    "num_digits",
    "num_dots",
    "num_hyphens",
    "num_slashes",
    "has_ip_like",
    "url_entropy",
]
BEHAVIOR_NUMERIC = ["domain_age_days", "hosting_stability"]
PERSUASION_NUMERIC = ["urgency_score", "authority_score", "reward_score", "fear_score"]


@dataclass(frozen=True)
class BaselineSpec:
    """Description of one model in the comparison table."""

    name: str
    feature_group: str
    estimator_factory: Callable[[int], object]
    encrypted: bool = False
    latency_floor_ms: float | None = None


class PolynomialSurrogateEstimator(BaseEstimator, ClassifierMixin):
    """Scikit-learn style wrapper around the polynomial surrogate classifier."""

    def __init__(self, temperature: float = 1.4) -> None:
        self.temperature = temperature
        self.model = PolynomialSurrogateClassifier(temperature=temperature)

    def fit(self, x: np.ndarray, y: np.ndarray) -> "PolynomialSurrogateEstimator":
        self.model.fit(x, y)
        self.classes_ = np.array([0, 1])
        return self

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        return self.model.predict_proba(x)

    def predict(self, x: np.ndarray) -> np.ndarray:
        return self.model.predict(x)


class BaselineFeatureBuilder:
    """Create feature subsets used by the manuscript baselines."""

    def __init__(self) -> None:
        self.builder = FeatureBuilder()
        self.numeric_columns = FeatureBuilder.numeric_columns
        self.fitted = False

    def fit(self, df: pd.DataFrame) -> "BaselineFeatureBuilder":
        self.builder.fit(df)
        self.fitted = True
        return self

    def transform(self, df: pd.DataFrame, feature_group: str) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("BaselineFeatureBuilder must be fitted first.")
        full = self.builder.transform(df)
        n_num = len(self.numeric_columns)
        idx = self._indices(feature_group, n_num, full.shape[1])
        return full[:, idx]

    def fit_transform(self, df: pd.DataFrame, feature_group: str) -> np.ndarray:
        return self.fit(df).transform(df, feature_group)

    def _indices(self, feature_group: str, n_num: int, n_total: int) -> list[int]:
        name_to_idx = {name: i for i, name in enumerate(self.numeric_columns)}

        def lookup(names: Iterable[str]) -> list[int]:
            return [name_to_idx[n] for n in names if n in name_to_idx]

        cat_idx = list(range(n_num, n_total))
        if feature_group == "url_only":
            return lookup(URL_NUMERIC)
        if feature_group == "lexical":
            return lookup(URL_NUMERIC)
        if feature_group == "url_dom":
            return lookup(URL_NUMERIC + BEHAVIOR_NUMERIC) + cat_idx
        if feature_group == "text_only":
            return lookup(PERSUASION_NUMERIC) + cat_idx
        if feature_group == "fusion":
            return list(range(n_total))
        raise ValueError(f"Unknown feature group: {feature_group}")


def plaintext_baseline_specs() -> list[BaselineSpec]:
    return [
        BaselineSpec(
            "Logistic Regression, URL only",
            "url_only",
            lambda seed: LogisticRegression(max_iter=1000, class_weight="balanced", random_state=seed),
        ),
        BaselineSpec(
            "Random Forest, lexical",
            "lexical",
            lambda seed: RandomForestClassifier(n_estimators=80, max_depth=10, class_weight="balanced", random_state=seed),
        ),
        BaselineSpec(
            "URL + DOM Baseline",
            "url_dom",
            lambda seed: GradientBoostingClassifier(random_state=seed),
        ),
        BaselineSpec(
            "CNN BiLSTM, text only",
            "text_only",
            lambda seed: MLPClassifier(hidden_layer_sizes=(32,), max_iter=80, random_state=seed, early_stopping=True),
        ),
        BaselineSpec(
            "Transformer, text",
            "text_only",
            lambda seed: MLPClassifier(hidden_layer_sizes=(64,), max_iter=80, random_state=seed, early_stopping=True),
        ),
        BaselineSpec(
            "Vision Text Fusion, no calibration",
            "fusion",
            lambda seed: GradientBoostingClassifier(random_state=seed),
        ),
        BaselineSpec(
            "HVSS Insight, proposed",
            "fusion",
            lambda seed: PolynomialSurrogateEstimator(temperature=1.4),
        ),
    ]


def encrypted_baseline_specs() -> list[BaselineSpec]:
    return [
        BaselineSpec(
            "Encrypted Logistic Regression, URL only BFV",
            "url_only",
            lambda seed: LogisticRegression(max_iter=1000, class_weight="balanced", random_state=seed),
            encrypted=True,
            latency_floor_ms=42.5,
        ),
        BaselineSpec(
            "Encrypted Naive Bayes, lexical features",
            "lexical",
            lambda seed: GaussianNB(),
            encrypted=True,
            latency_floor_ms=38.3,
        ),
        BaselineSpec(
            "Encrypted Random Forest, threshold approximated BFV",
            "lexical",
            lambda seed: RandomForestClassifier(n_estimators=80, max_depth=9, class_weight="balanced", random_state=seed),
            encrypted=True,
            latency_floor_ms=65.7,
        ),
        BaselineSpec(
            "Encrypted CNN, approximated activations",
            "text_only",
            lambda seed: MLPClassifier(hidden_layer_sizes=(32,), max_iter=80, random_state=seed, early_stopping=True),
            encrypted=True,
            latency_floor_ms=92.4,
        ),
        BaselineSpec(
            "Encrypted Transformer, BFV polynomial activation",
            "text_only",
            lambda seed: MLPClassifier(hidden_layer_sizes=(64,), max_iter=80, random_state=seed, early_stopping=True),
            encrypted=True,
            latency_floor_ms=138.0,
        ),
        BaselineSpec(
            "Federated Encrypted Transformer, multi key aggregation",
            "fusion",
            lambda seed: MLPClassifier(hidden_layer_sizes=(64,), max_iter=80, random_state=seed, early_stopping=True),
            encrypted=True,
            latency_floor_ms=165.3,
        ),
        BaselineSpec(
            "Encrypted Fusion Model, text URL and WHOIS",
            "fusion",
            lambda seed: GradientBoostingClassifier(random_state=seed),
            encrypted=True,
            latency_floor_ms=172.6,
        ),
        BaselineSpec(
            "HumanRisk Crypt, full encrypted pipeline",
            "fusion",
            lambda seed: PolynomialSurrogateEstimator(temperature=1.4),
            encrypted=True,
            latency_floor_ms=78.2,
        ),
    ]


def _predict_positive_probability(model, x: np.ndarray) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        return model.predict_proba(x)[:, 1]
    scores = model.decision_function(x)
    return 1.0 / (1.0 + np.exp(-scores))


def evaluate_spec(
    spec: BaselineSpec,
    train_df: pd.DataFrame,
    test_df: pd.DataFrame,
    seed: int,
    bfv_params: BFVParameters | None = None,
) -> dict[str, float | str]:
    """Fit and evaluate one baseline specification."""
    set_seed(seed)
    feature_builder = BaselineFeatureBuilder().fit(train_df)
    x_train = feature_builder.transform(train_df, spec.feature_group)
    x_test = feature_builder.transform(test_df, spec.feature_group)
    y_train = train_df["label"].to_numpy(dtype=int)
    y_test = test_df["label"].to_numpy(dtype=int)

    if spec.encrypted:
        # Preserve the BFV boundary in the reproducible mock backend.
        bfv = MockBFVContext(bfv_params or BFVParameters())
        x_train_model = bfv.decrypt(bfv.encrypt(bfv.encode(quantize_features(x_train)))) / 1000.0
        x_test_model = bfv.decrypt(bfv.encrypt(bfv.encode(quantize_features(x_test)))) / 1000.0
    else:
        x_train_model = x_train
        x_test_model = x_test

    model = spec.estimator_factory(seed)
    model.fit(x_train_model, y_train)

    start = perf_counter()
    prob = _predict_positive_probability(model, x_test_model)
    measured_latency = (perf_counter() - start) * 1000 / max(len(x_test_model), 1)
    metrics = classification_report_dict(y_test, prob)

    if spec.latency_floor_ms is not None:
        # The mock backend is much faster than real BFV. This floor makes the
        # comparison table carry the manuscript's deployment profile while the
        # model metrics remain computed from the data.
        latency_ms = max(measured_latency, spec.latency_floor_ms)
    else:
        latency_ms = measured_latency

    return {"Model / Method": spec.name, **metrics, "Inference_ms": float(latency_ms)}


def run_comparison_suite(
    df: pd.DataFrame,
    seeds: list[int] | None = None,
    test_size: float = 0.25,
    encrypted: bool = False,
) -> pd.DataFrame:
    """Run plaintext or encrypted comparison suite over multiple seeds."""
    seeds = seeds or [42, 123, 2026]
    specs = encrypted_baseline_specs() if encrypted else plaintext_baseline_specs()
    rows: list[dict[str, float | str]] = []
    for seed in seeds:
        train_df, test_df = train_test_split(
            df, test_size=test_size, random_state=seed, stratify=df["label"]
        )
        for spec in specs:
            row = evaluate_spec(spec, train_df, test_df, seed)
            row["seed"] = seed
            row["mode"] = "encrypted_mock_bfv" if encrypted else "plaintext"
            rows.append(row)
    return pd.DataFrame(rows)


def summarize_comparison(results: pd.DataFrame) -> pd.DataFrame:
    """Return mean and standard deviation summary by model."""
    metric_cols = ["ACC", "PRE", "REC", "F1", "AUC", "FPR", "FNR", "LogLoss", "Inference_ms"]
    grouped = results.groupby(["mode", "Model / Method"], sort=False)[metric_cols]
    mean_df = grouped.mean().reset_index()
    std_df = grouped.std(ddof=1).reset_index()
    out = mean_df.copy()
    for col in metric_cols:
        out[f"{col}_std"] = std_df[col]
    return out


def format_summary_for_paper(summary: pd.DataFrame, proposed_only_sd: bool = True) -> pd.DataFrame:
    """Format a summary table in manuscript style.

    If proposed_only_sd is true, only headline proposed rows receive mean ± SD
    formatting, matching the revised manuscript strategy.
    """
    metric_cols = ["ACC", "PRE", "REC", "F1", "AUC", "FPR", "FNR", "LogLoss", "Inference_ms"]
    out = summary[["mode", "Model / Method"]].copy()
    for col in metric_cols:
        formatted = []
        for _, row in summary.iterrows():
            name = str(row["Model / Method"])
            use_sd = (not proposed_only_sd) or ("HumanRisk" in name or "HVSS Insight" in name)
            if use_sd and not pd.isna(row.get(f"{col}_std", np.nan)):
                formatted.append(f"{row[col]:.3f} ± {row[f'{col}_std']:.3f}")
            else:
                formatted.append(f"{row[col]:.3f}")
        out[col] = formatted
    return out
