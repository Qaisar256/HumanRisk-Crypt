"""Reproducible 1,024-dimensional feature construction.

The paper configuration concatenates 512 local semantic features with 512
structured URL/metadata features. A hashing semantic backend exists only for
smoke tests; paper experiments require a local SentenceTransformer model.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.preprocessing import normalize


SEMANTIC_DIM = 512
STRUCTURED_DIM = 512
TOTAL_FEATURE_DIM = SEMANTIC_DIM + STRUCTURED_DIM


def _text_column(df: pd.DataFrame) -> list[str]:
    html = df.get("html_text", pd.Series([""] * len(df), index=df.index)).fillna("").astype(str)
    url = df.get("url", pd.Series([""] * len(df), index=df.index)).fillna("").astype(str)
    return (html + " [URL] " + url).tolist()


def _structured_documents(df: pd.DataFrame) -> list[str]:
    docs: list[str] = []
    for _, row in df.iterrows():
        url = str(row.get("url", ""))
        tokens = [
            url,
            f"sector={row.get('sector', 'unknown')}",
            f"brand={row.get('brand', 'unknown')}",
            f"source={row.get('source', 'unknown')}",
            f"domain_age_bin={int(float(row.get('domain_age_days', 0)) // 30)}",
            f"hosting={round(float(row.get('hosting_stability', 0.5)), 1)}",
            f"urgency={round(float(row.get('urgency_score', 0.0)), 1)}",
            f"authority={round(float(row.get('authority_score', 0.0)), 1)}",
            f"reward={round(float(row.get('reward_score', 0.0)), 1)}",
            f"fear={round(float(row.get('fear_score', 0.0)), 1)}",
        ]
        docs.append(" ".join(tokens))
    return docs


@dataclass(frozen=True)
class FeatureManifest:
    semantic_backend: str
    semantic_model: str
    semantic_dim: int = SEMANTIC_DIM
    structured_dim: int = STRUCTURED_DIM
    total_dim: int = TOTAL_FEATURE_DIM

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.__dict__, indent=2), encoding="utf-8")


class SemanticEncoder:
    def __init__(
        self,
        backend: Literal["sentence_transformer", "hashing"] = "sentence_transformer",
        model_name: str = "sentence-transformers/distiluse-base-multilingual-cased-v2",
        local_files_only: bool = True,
    ) -> None:
        self.backend = backend
        self.model_name = model_name
        self.local_files_only = local_files_only
        self._model = None
        self._hash = HashingVectorizer(
            n_features=SEMANTIC_DIM,
            alternate_sign=True,
            analyzer="word",
            ngram_range=(1, 2),
            norm="l2",
        )

    def _load_model(self):
        if self._model is not None:
            return self._model
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "sentence-transformers is required for paper feature extraction. "
                "The hashing backend is permitted only for smoke tests."
            ) from exc
        self._model = SentenceTransformer(
            self.model_name,
            local_files_only=self.local_files_only,
        )
        dimension = int(self._model.get_sentence_embedding_dimension())
        if dimension != SEMANTIC_DIM:
            raise ValueError(
                f"Semantic model returns {dimension} dimensions; the paper protocol requires {SEMANTIC_DIM}."
            )
        return self._model

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        texts = _text_column(df)
        if self.backend == "hashing":
            return self._hash.transform(texts).toarray().astype(np.float32)
        model = self._load_model()
        embeddings = model.encode(
            texts,
            batch_size=32,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return np.asarray(embeddings, dtype=np.float32)


class StructuredEncoder:
    def __init__(self) -> None:
        self.vectorizer = HashingVectorizer(
            n_features=STRUCTURED_DIM,
            alternate_sign=True,
            analyzer="char",
            ngram_range=(2, 5),
            norm="l2",
        )

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        return self.vectorizer.transform(_structured_documents(df)).toarray().astype(np.float32)


class FeatureBuilder:
    """Build exactly 1,024 dimensions without fitting on the test partition."""

    def __init__(
        self,
        semantic_backend: Literal["sentence_transformer", "hashing"] = "sentence_transformer",
        semantic_model: str = "sentence-transformers/distiluse-base-multilingual-cased-v2",
        local_files_only: bool = True,
    ) -> None:
        self.semantic = SemanticEncoder(semantic_backend, semantic_model, local_files_only)
        self.structured = StructuredEncoder()
        self.manifest = FeatureManifest(semantic_backend, semantic_model)
        self.fitted = False

    def fit(self, df: pd.DataFrame) -> "FeatureBuilder":
        # Both encoders are fixed/pretrained. This method exists for pipeline parity.
        if len(df) == 0:
            raise ValueError("Cannot fit FeatureBuilder on an empty dataframe")
        self.fitted = True
        return self

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("FeatureBuilder must be fitted before transform")
        semantic = self.semantic.transform(df)
        structured = self.structured.transform(df)
        x = np.hstack([semantic, structured]).astype(np.float32)
        if x.shape[1] != TOTAL_FEATURE_DIM:
            raise AssertionError(f"Expected {TOTAL_FEATURE_DIM} features, got {x.shape[1]}")
        return normalize(x, norm="l2").astype(np.float32)

    def fit_transform(self, df: pd.DataFrame) -> np.ndarray:
        return self.fit(df).transform(df)


def quantize_features(x: np.ndarray, scale: int = 8, clip: float = 1.0) -> np.ndarray:
    """Quantize normalized features into small signed BFV integers."""
    if scale <= 0:
        raise ValueError("scale must be positive")
    clipped = np.clip(np.asarray(x, dtype=np.float64), -clip, clip)
    return np.rint(clipped * scale).astype(np.int64)
