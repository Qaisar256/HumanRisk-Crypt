"""Feature extraction for phishing artifacts."""
from __future__ import annotations

import math
import re
from typing import Dict, Tuple
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def shannon_entropy(text: str) -> float:
    if not isinstance(text, str) or not text:
        return 0.0
    counts = {ch: text.count(ch) for ch in set(text)}
    total = len(text)
    return float(-sum((c / total) * math.log2(c / total) for c in counts.values()))


def extract_url_features(url: str) -> Dict[str, float]:
    url = url or ""
    return {
        "url_length": len(url),
        "num_digits": sum(ch.isdigit() for ch in url),
        "num_dots": url.count("."),
        "num_hyphens": url.count("-"),
        "num_slashes": url.count("/"),
        "has_ip_like": float(bool(re.search(r"\d+\.\d+\.\d+\.\d+", url))),
        "url_entropy": shannon_entropy(url),
    }


class FeatureBuilder:
    """Build fixed dimensional numeric feature vectors from phishing records."""

    numeric_columns = [
        "url_length", "num_digits", "num_dots", "num_hyphens", "num_slashes",
        "has_ip_like", "url_entropy", "domain_age_days", "hosting_stability",
        "urgency_score", "authority_score", "reward_score", "fear_score",
    ]
    categorical_columns = ["sector", "brand"]

    def __init__(self) -> None:
        self.scaler = StandardScaler()
        self.encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        self.fitted = False

    def _ensure_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if "url" in df.columns:
            url_feats = df["url"].fillna("").map(extract_url_features).apply(pd.Series)
            for col in url_feats.columns:
                if col not in df.columns:
                    df[col] = url_feats[col]
        for col in self.numeric_columns:
            if col not in df.columns:
                df[col] = 0.0
        for col in self.categorical_columns:
            if col not in df.columns:
                df[col] = "unknown"
        return df

    def fit(self, df: pd.DataFrame) -> "FeatureBuilder":
        df = self._ensure_columns(df)
        self.scaler.fit(df[self.numeric_columns].astype(float))
        self.encoder.fit(df[self.categorical_columns].astype(str))
        self.fitted = True
        return self

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("FeatureBuilder must be fitted before transform.")
        df = self._ensure_columns(df)
        x_num = self.scaler.transform(df[self.numeric_columns].astype(float))
        x_cat = self.encoder.transform(df[self.categorical_columns].astype(str))
        return np.hstack([x_num, x_cat]).astype(np.float64)

    def fit_transform(self, df: pd.DataFrame) -> np.ndarray:
        return self.fit(df).transform(df)


def quantize_features(x: np.ndarray, scale: int = 1000) -> np.ndarray:
    """Convert normalized float features into BFV-compatible integers."""
    return np.rint(x * scale).astype(np.int64)
