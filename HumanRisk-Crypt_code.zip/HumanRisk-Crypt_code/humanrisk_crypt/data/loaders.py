"""Strict real-dataset loading, schema validation, and domain canonicalization."""
from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse
import ipaddress

import pandas as pd

REQUIRED_COLUMNS = {"url", "label", "timestamp"}
_EXTRACTOR = None


def canonical_registered_domain(url: str) -> str:
    """Return a PSL-aware registered domain using tldextract's bundled snapshot."""
    host = (urlparse(str(url)).hostname or "").lower().strip(".")
    if not host:
        raise ValueError(f"URL has no hostname: {url!r}")
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass

    global _EXTRACTOR
    try:
        import tldextract
    except ImportError as exc:
        raise RuntimeError(
            "tldextract is required to derive registered_domain reproducibly. "
            "Install requirements.txt or provide a validated registered_domain column."
        ) from exc
    if _EXTRACTOR is None:
        # Disable network access. This uses the suffix-list snapshot bundled with
        # the pinned package, making domain derivation deterministic per release.
        _EXTRACTOR = tldextract.TLDExtract(suffix_list_urls=())
    parts = _EXTRACTOR(host)
    if parts.domain and parts.suffix:
        return f"{parts.domain}.{parts.suffix}".lower()
    return host


def validate_dataset(df: pd.DataFrame, source: str = "dataset") -> pd.DataFrame:
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"{source} is missing required columns: {sorted(missing)}")
    out = df.copy()
    out["url"] = out["url"].astype(str)
    out["label"] = pd.to_numeric(out["label"], errors="raise").astype(int)
    if not set(out["label"].unique()).issubset({0, 1}):
        raise ValueError(f"{source}: label must contain only 0 and 1")
    out["timestamp"] = pd.to_datetime(out["timestamp"], utc=True, errors="coerce")
    if out["timestamp"].isna().any():
        raise ValueError(f"{source}: timestamp contains missing or invalid values")

    if "registered_domain" not in out.columns:
        out["registered_domain"] = out["url"].map(canonical_registered_domain)
    else:
        out["registered_domain"] = (
            out["registered_domain"].fillna("").astype(str).str.lower().str.strip(".")
        )
        missing_domain = out["registered_domain"].eq("")
        if missing_domain.any():
            out.loc[missing_domain, "registered_domain"] = out.loc[
                missing_domain, "url"
            ].map(canonical_registered_domain)
    if out["registered_domain"].eq("").any():
        raise ValueError(f"{source}: registered_domain contains empty values")
    return out


def load_csv_dataset(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")
    return validate_dataset(pd.read_csv(path), source=str(path))


def load_available_datasets(root: str | Path = "datasets") -> pd.DataFrame:
    root = Path(root)
    files = [
        root / "openphish" / "openphish.csv",
        root / "phishtank" / "phishtank.csv",
        root / "apwg" / "apwg.csv",
    ]
    frames: list[pd.DataFrame] = []
    for file in files:
        if file.exists():
            frame = load_csv_dataset(file)
            frame["source"] = file.parent.name
            frames.append(frame)
    if not frames:
        raise FileNotFoundError(
            "No real dataset files were found. Paper experiment scripts do not "
            "fall back to synthetic data. See datasets/README.md."
        )
    return pd.concat(frames, ignore_index=True)
