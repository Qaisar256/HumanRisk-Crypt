"""Dataset loaders for HumanRisk Crypt."""
from __future__ import annotations

from pathlib import Path
import pandas as pd


def load_csv_dataset(path: str | Path) -> pd.DataFrame:
    """Load a phishing dataset CSV file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")
    df = pd.read_csv(path)
    if "label" not in df.columns:
        raise ValueError("Dataset must include a 'label' column with 1 phishing and 0 benign.")
    return df


def load_available_datasets(root: str | Path = "datasets") -> pd.DataFrame:
    """Load available OpenPhish, PhishTank, and APWG CSV files if present."""
    root = Path(root)
    files = [
        root / "openphish" / "openphish.csv",
        root / "phishtank" / "phishtank.csv",
        root / "apwg" / "apwg.csv",
    ]
    frames = []
    for file in files:
        if file.exists():
            frame = pd.read_csv(file)
            frame["source"] = file.parent.name
            frames.append(frame)
    if not frames:
        raise FileNotFoundError("No dataset CSV files found under datasets/{openphish,phishtank,apwg}.")
    return pd.concat(frames, ignore_index=True)
