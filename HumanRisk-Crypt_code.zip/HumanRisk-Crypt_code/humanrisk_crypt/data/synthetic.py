"""Synthetic smoke-test data.

The generator samples a latent risk process first and then samples both labels
and observable features conditionally on that latent variable. No feature is
constructed directly from the realized class label.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_synthetic_phishing_dataset(n_samples: int = 1000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n_domains = max(60, n_samples // 5)
    domain_ids = rng.integers(0, n_domains, size=n_samples)
    domain_effect = rng.normal(0.0, 0.75, size=n_domains)[domain_ids]
    latent = rng.normal(0.0, 1.0, size=n_samples) + domain_effect
    label_probability = 1.0 / (1.0 + np.exp(-(0.75 * latent + rng.normal(0, 0.9, n_samples))))
    labels = rng.binomial(1, label_probability)

    dates = pd.Timestamp("2024-01-01", tz="UTC") + pd.to_timedelta(
        np.sort(rng.integers(0, 730, size=n_samples)), unit="D"
    )
    suspiciousness = 1.0 / (1.0 + np.exp(-latent))
    domain_age = np.exp(rng.normal(5.5 - 1.2 * suspiciousness, 1.0)).clip(1, 5000)
    stability = np.clip(0.72 - 0.35 * suspiciousness + rng.normal(0, 0.20, n_samples), 0, 1)
    urgency = np.clip(0.25 + 0.45 * suspiciousness + rng.normal(0, 0.22, n_samples), 0, 1)
    authority = np.clip(0.28 + 0.35 * suspiciousness + rng.normal(0, 0.24, n_samples), 0, 1)
    reward = np.clip(0.18 + 0.30 * suspiciousness + rng.normal(0, 0.25, n_samples), 0, 1)
    fear = np.clip(0.20 + 0.42 * suspiciousness + rng.normal(0, 0.23, n_samples), 0, 1)

    domains = np.array([f"site-{i}.example" for i in domain_ids])
    paths = rng.choice(["login", "verify", "invoice", "account", "home"], size=n_samples)
    token = rng.integers(1000, 999999, size=n_samples)
    urls = [f"https://{d}/{p}?id={t}" for d, p, t in zip(domains, paths, token)]
    templates = np.where(
        suspiciousness > 0.6,
        "Urgent account verification requested. Confirm credentials to avoid service interruption.",
        "Account information and service notice. Review the details through the normal portal.",
    )
    html_text = [f"{text} Reference {int(t)}" for text, t in zip(templates, token)]

    return pd.DataFrame(
        {
            "timestamp": dates,
            "registered_domain": domains,
            "url": urls,
            "html_text": html_text,
            "label": labels.astype(int),
            "domain_age_days": domain_age.round().astype(int),
            "hosting_stability": stability.round(4),
            "urgency_score": urgency.round(4),
            "authority_score": authority.round(4),
            "reward_score": reward.round(4),
            "fear_score": fear.round(4),
            "sector": rng.choice(["finance", "cloud", "retail", "government", "telecom"], n_samples),
            "brand": rng.choice(["bank", "mail", "cloud", "shop", "government", "none"], n_samples),
        }
    )
