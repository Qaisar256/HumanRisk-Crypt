"""Synthetic dataset generator for pipeline testing."""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_synthetic_phishing_dataset(n_samples: int = 1000, seed: int = 42) -> pd.DataFrame:
    """Create a synthetic phishing dataset with URL, behavioral, and persuasion fields.

    This dataset is only for reproducible code testing. It is not a substitute for
    OpenPhish, PhishTank, or APWG feeds.
    """
    rng = np.random.default_rng(seed)
    labels = rng.binomial(1, 0.5, size=n_samples)

    url_len = rng.normal(45 + 35 * labels, 12, size=n_samples).clip(8, 180)
    num_digits = rng.poisson(2 + 5 * labels, size=n_samples)
    entropy = rng.normal(3.2 + 0.8 * labels, 0.35, size=n_samples).clip(1.5, 5.5)
    domain_age_days = rng.exponential(500 - 420 * labels + 1, size=n_samples).clip(1, 2500)
    hosting_stability = rng.beta(5 - 3 * labels + 0.1, 2 + 2 * labels, size=n_samples).clip(0, 1)

    urgency = rng.beta(2 + 4 * labels, 6 - 3 * labels + 0.1, size=n_samples).clip(0, 1)
    authority = rng.beta(2 + 3 * labels, 5 - 2 * labels + 0.1, size=n_samples).clip(0, 1)
    reward = rng.beta(1.5 + 2 * labels, 6 - 2 * labels + 0.1, size=n_samples).clip(0, 1)
    fear = rng.beta(1.5 + 3 * labels, 6 - 2 * labels + 0.1, size=n_samples).clip(0, 1)

    sectors = np.array(["finance", "cloud", "ecommerce", "government", "telecom"])
    brands = np.array(["bank", "mail", "cloud", "shop", "gov", "none"])

    df = pd.DataFrame({
        "url": [f"https://example{i}.com/login" for i in range(n_samples)],
        "label": labels,
        "url_length": url_len.round(0).astype(int),
        "num_digits": num_digits,
        "url_entropy": entropy.round(3),
        "domain_age_days": domain_age_days.round(0).astype(int),
        "hosting_stability": hosting_stability.round(3),
        "urgency_score": urgency.round(3),
        "authority_score": authority.round(3),
        "reward_score": reward.round(3),
        "fear_score": fear.round(3),
        "sector": rng.choice(sectors, size=n_samples),
        "brand": rng.choice(brands, size=n_samples),
    })
    return df
