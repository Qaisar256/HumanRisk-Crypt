"""Time-aware and domain-disjoint dataset splitting."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from urllib.parse import urlparse
import ipaddress

import numpy as np
import pandas as pd


def domain_key(url: str) -> str:
    host = (urlparse(str(url)).hostname or "").lower().strip(".")
    if not host:
        return "missing-domain"
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass
    labels = [p for p in host.split(".") if p]
    # Stable leakage-control key. This deliberately avoids an online suffix-list
    # download; users may provide a canonical ``registered_domain`` column.
    return ".".join(labels[-2:]) if len(labels) >= 2 else host


@dataclass(frozen=True)
class SplitAudit:
    cutoff_timestamp: str
    train_rows: int
    test_rows: int
    train_domains: int
    test_domains: int
    domain_overlap: int
    train_max_timestamp: str
    test_min_timestamp: str
    dropped_pre_cutoff_rows_from_test_domains: int

    def to_dict(self) -> dict:
        return asdict(self)


def time_domain_split(
    df: pd.DataFrame,
    test_fraction: float = 0.25,
    timestamp_column: str = "timestamp",
    url_column: str = "url",
    domain_column: str = "registered_domain",
) -> tuple[pd.DataFrame, pd.DataFrame, SplitAudit]:
    """Create a chronological test set with strict domain separation.

    Test domains are selected only from records at or after the temporal cutoff.
    Earlier records sharing those domains are removed from training. This prevents
    both future leakage and domain duplication between partitions.
    """
    if not 0.05 <= test_fraction <= 0.5:
        raise ValueError("test_fraction must be between 0.05 and 0.5")
    if timestamp_column not in df.columns:
        raise ValueError(f"Missing required timestamp column: {timestamp_column}")
    if url_column not in df.columns and domain_column not in df.columns:
        raise ValueError(f"Provide either {url_column!r} or {domain_column!r}")

    work = df.copy()
    work[timestamp_column] = pd.to_datetime(work[timestamp_column], utc=True, errors="coerce")
    if work[timestamp_column].isna().any():
        bad = int(work[timestamp_column].isna().sum())
        raise ValueError(f"{bad} rows contain missing or invalid timestamps")
    if domain_column not in work.columns:
        work[domain_column] = work[url_column].map(domain_key)
    work[domain_column] = work[domain_column].fillna("missing-domain").astype(str).str.lower()

    cutoff = work[timestamp_column].quantile(1.0 - test_fraction, interpolation="nearest")
    candidate_test = work.loc[work[timestamp_column] >= cutoff].copy()
    test_domains = set(candidate_test[domain_column])
    train_mask = (work[timestamp_column] < cutoff) & (~work[domain_column].isin(test_domains))
    train = work.loc[train_mask].sort_values(timestamp_column).reset_index(drop=True)
    test = candidate_test.sort_values(timestamp_column).reset_index(drop=True)
    dropped = int(((work[timestamp_column] < cutoff) & work[domain_column].isin(test_domains)).sum())

    if train.empty or test.empty:
        raise ValueError("Leakage-controlled split produced an empty partition")
    if train["label"].nunique() < 2 or test["label"].nunique() < 2:
        raise ValueError("Both train and test partitions must contain both classes")

    overlap = set(train[domain_column]) & set(test[domain_column])
    if overlap:
        raise AssertionError("Domain separation failed")
    if train[timestamp_column].max() >= test[timestamp_column].min():
        raise AssertionError("Temporal ordering failed")

    audit = SplitAudit(
        cutoff_timestamp=cutoff.isoformat(),
        train_rows=len(train),
        test_rows=len(test),
        train_domains=train[domain_column].nunique(),
        test_domains=test[domain_column].nunique(),
        domain_overlap=0,
        train_max_timestamp=train[timestamp_column].max().isoformat(),
        test_min_timestamp=test[timestamp_column].min().isoformat(),
        dropped_pre_cutoff_rows_from_test_domains=dropped,
    )
    return train, test, audit
