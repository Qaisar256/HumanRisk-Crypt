"""End-to-end HumanRisk Crypt pipeline."""
from __future__ import annotations

from dataclasses import dataclass
import time
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from humanrisk_crypt.crypto.bfv_interface import BFVParameters, MockBFVContext
from humanrisk_crypt.data.feature_extraction import FeatureBuilder, quantize_features
from humanrisk_crypt.models.polynomial_model import PolynomialSurrogateClassifier
from humanrisk_crypt.ehvss.scoring import EHVSSScorer
from humanrisk_crypt.ontology.attack_mapping import AttackTechniqueMapper
from humanrisk_crypt.evaluation.metrics import classification_report_dict


@dataclass
class PipelineResult:
    metrics: dict[str, float]
    latency_ms: float
    output_frame: pd.DataFrame


class HumanRiskCryptPipeline:
    """Train and run the HumanRisk Crypt pipeline."""

    def __init__(self, bfv_params: BFVParameters | None = None, temperature: float = 1.4) -> None:
        self.features = FeatureBuilder()
        self.bfv = MockBFVContext(bfv_params or BFVParameters())
        self.model = PolynomialSurrogateClassifier(temperature=temperature)
        self.scorer = EHVSSScorer()
        self.mapper = AttackTechniqueMapper()

    def fit(self, df: pd.DataFrame) -> "HumanRiskCryptPipeline":
        x = self.features.fit_transform(df)
        y = df["label"].to_numpy(dtype=int)
        self.model.fit(x, y)
        return self

    def predict(self, df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, list[dict], float]:
        x = self.features.transform(df)
        # The mock backend keeps normalized features for numerical stability.
        # In a real BFV backend, replace this with quantize_features(x) before encoding.
        start = time.perf_counter()
        mx = self.bfv.encode(x)
        ct_x = self.bfv.encrypt(mx)
        ct_prob = self.model.encrypted_predict_proba(self.bfv, ct_x)
        prob = self.bfv.decrypt(ct_prob)
        ct_score = self.scorer.encrypted_score(self.bfv, ct_prob, df)
        score = self.bfv.decrypt(ct_score)
        latency_ms = (time.perf_counter() - start) * 1000 / max(len(df), 1)

        techniques = self.mapper.map_records(df, prob)
        return prob, score, techniques, latency_ms

    def fit_evaluate(self, df: pd.DataFrame, test_size: float = 0.25, seed: int = 42) -> PipelineResult:
        train_df, test_df = train_test_split(
            df, test_size=test_size, random_state=seed, stratify=df["label"]
        )
        self.fit(train_df)
        prob, score, techniques, latency_ms = self.predict(test_df)
        metrics = classification_report_dict(test_df["label"].to_numpy(dtype=int), prob)
        out = test_df.copy().reset_index(drop=True)
        out["phishing_probability"] = prob
        out["ehvss_score"] = score
        out["risk_label"] = self.scorer.risk_label(score)
        out["attack_id"] = [t["attack_id"] for t in techniques]
        out["attack_name"] = [t["attack_name"] for t in techniques]
        return PipelineResult(metrics, latency_ms, out)
