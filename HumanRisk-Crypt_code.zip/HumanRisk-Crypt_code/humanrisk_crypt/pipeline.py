"""End-to-end training, leakage-controlled evaluation, and real BFV inference."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import mean
from typing import Any, Literal

import numpy as np
import pandas as pd

from humanrisk_crypt.crypto.bfv_interface import (
    BFVParameters,
    CryptoTiming,
    MockBFVContext,
    TenSEALBFVContext,
    timed_call,
)
from humanrisk_crypt.data.feature_extraction import FeatureBuilder, quantize_features
from humanrisk_crypt.data.splitting import SplitAudit, time_domain_split
from humanrisk_crypt.ehvss.scoring import EHVSSScorer
from humanrisk_crypt.evaluation.metrics import classification_report_dict
from humanrisk_crypt.models.polynomial_model import PolynomialSurrogateClassifier
from humanrisk_crypt.ontology.attack_mapping import AttackTechniqueMapper


@dataclass
class EncryptedInferenceAudit:
    backend: str
    cryptographic: bool
    samples: int
    exact_decryption_matches: int
    overflow_checks_passed: int
    public_context_bytes: int
    total_request_bytes: int
    total_response_bytes: int
    total_communication_bytes_including_setup: int
    amortized_communication_bytes_per_sample: float
    mean_request_bytes: float
    mean_response_bytes: float
    client_context_setup_ms: float
    public_context_serialize_ms: float
    server_context_load_ms: float
    mean_total_ms: float
    mean_encode_encrypt_ms: float
    mean_homomorphic_eval_ms: float
    mean_decrypt_ms: float
    noise_budget_before_bits: float | None
    noise_budget_after_bits: float | None


@dataclass
class PipelineResult:
    metrics: dict[str, float]
    split_audit: dict
    encrypted_audit: dict
    output_frame: pd.DataFrame
    per_sample_crypto: pd.DataFrame


class HumanRiskCryptPipeline:
    def __init__(
        self,
        backend: Literal["tenseal", "mock"] = "tenseal",
        semantic_backend: Literal["sentence_transformer", "hashing"] = "sentence_transformer",
        bfv_params: BFVParameters | None = None,
        demo_mode: bool = False,
        seed: int = 42,
        local_files_only: bool = True,
        semantic_model: str = "sentence-transformers/distiluse-base-multilingual-cased-v2",
        model_kwargs: dict[str, Any] | None = None,
    ) -> None:
        if backend not in {"tenseal", "mock"}:
            raise ValueError(f"Unsupported BFV backend: {backend}")
        if semantic_backend not in {"sentence_transformer", "hashing"}:
            raise ValueError(f"Unsupported semantic backend: {semantic_backend}")
        if backend == "mock" and not demo_mode:
            raise ValueError("Mock BFV is allowed only when demo_mode=True")
        if semantic_backend == "hashing" and not demo_mode:
            raise ValueError("Hashing semantic features are allowed only in demo_mode")
        self.demo_mode = demo_mode
        self.params = bfv_params or BFVParameters()
        self.features = FeatureBuilder(
            semantic_backend=semantic_backend,
            semantic_model=semantic_model,
            local_files_only=local_files_only,
        )
        context_factory = TenSEALBFVContext if backend == "tenseal" else MockBFVContext
        self.client_bfv, self.client_context_setup_ms = timed_call(context_factory, self.params)
        if backend == "tenseal":
            public_blob, self.public_context_serialize_ms = timed_call(
                self.client_bfv.public_context_bytes
            )
            self.public_context_bytes = len(public_blob)
            self.server_bfv, self.server_context_load_ms = timed_call(
                TenSEALBFVContext.from_public_context_bytes, public_blob, self.params
            )
        else:
            self.public_context_serialize_ms = 0.0
            self.public_context_bytes = 0
            self.server_context_load_ms = 0.0
            self.server_bfv = self.client_bfv
        resolved_model_kwargs = dict(model_kwargs or {})
        resolved_model_kwargs.setdefault("seed", seed)
        self.model = PolynomialSurrogateClassifier(**resolved_model_kwargs)
        self.scorer = EHVSSScorer(use_demo_heuristic=demo_mode)
        self.mapper = AttackTechniqueMapper()
        self.fitted = False

    def fit(self, df: pd.DataFrame) -> "HumanRiskCryptPipeline":
        x = self.features.fit_transform(df)
        y = df["label"].to_numpy(dtype=int)
        self.model.fit(x, y)
        self.fitted = True
        if "expert_ehvss" in df.columns:
            plaintext_prob = self.model.predict_proba(x)[:, 1]
            expert_ids = df["expert_id"].to_numpy() if "expert_id" in df.columns else None
            self.scorer.fit(
                df,
                plaintext_prob,
                df["expert_ehvss"].to_numpy(dtype=float),
                expert_ids=expert_ids,
            )
        return self

    def _infer_one(self, x_row: np.ndarray) -> tuple[float, CryptoTiming, bool, bool, int]:
        params = self.model.export_quantized()
        x_int = quantize_features(x_row.reshape(1, -1), scale=params.feature_scale)[0]
        arithmetic_bound = self.model.arithmetic_bound(x_int, params)
        overflow_ok = arithmetic_bound < self.params.centered_plaintext_limit
        if not overflow_ok:
            raise OverflowError(
                "BFV plaintext-modulus audit failed: worst-case absolute polynomial "
                f"value {arithmetic_bound} is not below centered limit "
                f"{self.params.centered_plaintext_limit}. Reduce quantization scales "
                "or select a validated larger batching plaintext modulus."
            )

        timing = CryptoTiming()
        ct_request, timing.encode_encrypt_ms = timed_call(self.client_bfv.encrypt_vector, x_int)
        timing.noise_budget_before_bits = self.client_bfv.noise_budget_bits(ct_request)
        request_blob, timing.serialize_request_ms = timed_call(
            self.client_bfv.serialize_ciphertext, ct_request
        )
        timing.request_bytes = len(request_blob)
        server_request, timing.deserialize_request_ms = timed_call(
            self.server_bfv.deserialize_ciphertext, request_blob
        )
        server_result, timing.homomorphic_eval_ms = timed_call(
            self.model.encrypted_integer_logit, server_request, params
        )
        response_blob, timing.serialize_response_ms = timed_call(
            self.server_bfv.serialize_ciphertext, server_result
        )
        timing.response_bytes = len(response_blob)
        client_result, timing.deserialize_response_ms = timed_call(
            self.client_bfv.deserialize_ciphertext, response_blob
        )
        timing.noise_budget_after_bits = self.client_bfv.noise_budget_bits(client_result)
        decrypted, timing.decrypt_ms = timed_call(self.client_bfv.decrypt_vector, client_result)
        encrypted_integer = int(decrypted[0])
        plaintext_integer = self.model.plaintext_integer_logit(x_int, params)
        exact = encrypted_integer == plaintext_integer
        if not exact:
            raise ArithmeticError(
                "Encrypted and plaintext integer logits differ. This usually signals "
                "plaintext-modulus wraparound or exhausted BFV noise budget."
            )
        probability = self.model.probability_from_integer_logit(
            encrypted_integer, params.weight_scale
        )
        return probability, timing, exact, overflow_ok, arithmetic_bound

    def predict(self, df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, list[dict], pd.DataFrame, dict]:
        if not self.fitted:
            raise RuntimeError("Pipeline must be fitted before prediction")
        x = self.features.transform(df)
        probabilities: list[float] = []
        traces: list[dict] = []
        timings: list[CryptoTiming] = []
        exact_matches = 0
        overflow_passed = 0
        for i, row in enumerate(x):
            prob, timing, exact, overflow_ok, bound = self._infer_one(row)
            probabilities.append(prob)
            timings.append(timing)
            exact_matches += int(exact)
            overflow_passed += int(overflow_ok)
            traces.append(
                {
                    "sample_index": i,
                    **asdict(timing),
                    "total_ms": timing.total_ms,
                    "exact_integer_match": exact,
                    "plaintext_arithmetic_bound": bound,
                    "overflow_check_passed": overflow_ok,
                }
            )
        prob_array = np.asarray(probabilities, dtype=float)
        score = self.scorer.score(df, prob_array)
        techniques = self.mapper.map_records(df, prob_array)

        def avg_optional(values: list[int | None]) -> float | None:
            available = [float(v) for v in values if v is not None]
            return mean(available) if available else None

        total_request_bytes = int(sum(t.request_bytes for t in timings))
        total_response_bytes = int(sum(t.response_bytes for t in timings))
        total_communication = self.public_context_bytes + total_request_bytes + total_response_bytes
        audit = EncryptedInferenceAudit(
            backend=self.client_bfv.backend_name,
            cryptographic=bool(self.client_bfv.cryptographic),
            samples=len(df),
            exact_decryption_matches=exact_matches,
            overflow_checks_passed=overflow_passed,
            public_context_bytes=self.public_context_bytes,
            total_request_bytes=total_request_bytes,
            total_response_bytes=total_response_bytes,
            total_communication_bytes_including_setup=total_communication,
            amortized_communication_bytes_per_sample=total_communication / len(df),
            mean_request_bytes=mean([t.request_bytes for t in timings]),
            mean_response_bytes=mean([t.response_bytes for t in timings]),
            client_context_setup_ms=self.client_context_setup_ms,
            public_context_serialize_ms=self.public_context_serialize_ms,
            server_context_load_ms=self.server_context_load_ms,
            mean_total_ms=mean([t.total_ms for t in timings]),
            mean_encode_encrypt_ms=mean([t.encode_encrypt_ms for t in timings]),
            mean_homomorphic_eval_ms=mean([t.homomorphic_eval_ms for t in timings]),
            mean_decrypt_ms=mean([t.decrypt_ms for t in timings]),
            noise_budget_before_bits=avg_optional([t.noise_budget_before_bits for t in timings]),
            noise_budget_after_bits=avg_optional([t.noise_budget_after_bits for t in timings]),
        )
        return prob_array, score, techniques, pd.DataFrame(traces), asdict(audit)

    def fit_evaluate(self, df: pd.DataFrame, test_fraction: float = 0.25) -> PipelineResult:
        train_df, test_df, split_audit = time_domain_split(df, test_fraction=test_fraction)
        self.fit(train_df)
        prob, score, techniques, traces, crypto_audit = self.predict(test_df)
        metrics = classification_report_dict(test_df["label"].to_numpy(dtype=int), prob)
        out = test_df.copy().reset_index(drop=True)
        out["phishing_probability"] = prob
        out["ehvss_score"] = score
        out["risk_label"] = self.scorer.risk_label(score)
        out["attack_id"] = [t["attack_id"] for t in techniques]
        out["attack_name"] = [t["attack_name"] for t in techniques]
        out["attack_evidence"] = [";".join(t["evidence"]) for t in techniques]
        return PipelineResult(metrics, split_audit.to_dict(), crypto_audit, out, traces)
