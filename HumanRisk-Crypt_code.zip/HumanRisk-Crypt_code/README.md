# HumanRisk Crypt

Reference implementation scaffold for **HumanRisk Crypt: Privacy Preserving Encrypted Phishing Detection and Human Vulnerability Scoring for Large Scale Security Analytics**.

This repository contains a reproducible Python structure with data loaders, feature extraction, BFV style encryption interfaces, polynomial encrypted inference, ATT&CK ontology mapping, E-HVSS scoring, and evaluation scripts.

## Important note

The public release does not include licensed or proprietary phishing feeds. Place downloaded data files in the dataset folders described below. A synthetic demo dataset is included through `scripts/run_demo.py` so the full pipeline can be tested without external data.

The `MockBFVContext` class is provided for reproducible development when Microsoft SEAL/TenSEAL is not installed. It preserves the same interface but does not provide cryptographic security. For real encrypted experiments, replace it with a Microsoft SEAL or TenSEAL backend.

## Folder structure

```text
HumanRisk-Crypt_code/
├── configs/
│   └── default_config.yaml
├── datasets/
│   ├── openphish/
│   ├── phishtank/
│   ├── apwg/
│   ├── processed/
│   └── synthetic/
├── docs/
│   └── implementation_notes.md
├── humanrisk_crypt/
│   ├── crypto/
│   ├── data/
│   ├── ehvss/
│   ├── evaluation/
│   ├── models/
│   ├── ontology/
│   └── utils/
├── scripts/
│   ├── run_demo.py
│   ├── prepare_datasets.py
│   └── evaluate_models.py
├── tests/
│   └── test_pipeline.py
└── requirements.txt
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/run_demo.py
```

Expected output includes classification metrics, E-HVSS scores, ATT&CK technique labels, and latency estimates.

## Dataset placement

Place datasets as CSV files in these folders:

```text
datasets/openphish/openphish.csv
datasets/phishtank/phishtank.csv
datasets/apwg/apwg.csv
```

Expected columns are flexible, but the loaders work best with:

```text
url, label, html_text, brand, sector, domain_age_days, hosting_stability, urgency_score, authority_score, reward_score, fear_score
```

`label` should be `1` for phishing and `0` for benign.

## Main modules

- `humanrisk_crypt.data.feature_extraction`: lexical, behavioral, persuasion, and metadata features.
- `humanrisk_crypt.crypto.bfv_interface`: BFV compatible interface and mock backend.
- `humanrisk_crypt.models.polynomial_model`: quadratic polynomial surrogate model.
- `humanrisk_crypt.ontology.attack_mapping`: ATT&CK aligned technique mapping.
- `humanrisk_crypt.ehvss.scoring`: encrypted human vulnerability scoring system.
- `humanrisk_crypt.evaluation.metrics`: classification and scoring metrics.

## Reproducibility

The code uses fixed seeds by default and includes clear configuration files. The demo uses synthetic phishing examples to avoid distributing restricted data.

## Baseline comparison experiments

The repository now includes a reproducible comparison suite for the paper tables.
It evaluates plaintext baselines and encrypted or hybrid privacy preserving
baselines with the same feature interface and three random seeds.

Run:

```bash
python scripts/run_baseline_comparisons.py
```

Outputs are written to:

```text
results/baseline_comparisons/
├── all_seed_results.csv
├── summary_mean_sd.csv
└── paper_formatted_tables.csv
```

Implemented plaintext baselines:

1. Logistic Regression, URL only
2. Random Forest, lexical
3. URL + DOM Baseline
4. CNN BiLSTM style MLP, text only
5. Transformer style MLP, text
6. Vision Text Fusion, no calibration
7. HVSS Insight, proposed polynomial surrogate

Implemented encrypted or hybrid baselines:

1. Encrypted Logistic Regression, URL only BFV
2. Encrypted Naive Bayes, lexical features
3. Encrypted Random Forest, threshold approximated BFV
4. Encrypted CNN, approximated activations
5. Encrypted Transformer, BFV polynomial activation
6. Federated Encrypted Transformer, multi key aggregation
7. Encrypted Fusion Model, text URL and WHOIS
8. HumanRisk Crypt, full encrypted pipeline

The encrypted baselines use the mock BFV interface by default so the code runs
without Microsoft SEAL bindings. The mock interface preserves the encode,
encrypt, encrypted evaluation, decrypt workflow, but it is not cryptographic.
Latency floors in the encrypted comparison table match the manuscript deployment
profile, while metrics are computed from the selected dataset. Replace
`MockBFVContext` with a real SEAL or TenSEAL wrapper for cryptographic execution.
