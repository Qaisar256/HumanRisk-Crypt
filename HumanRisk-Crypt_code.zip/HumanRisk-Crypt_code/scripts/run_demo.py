#!/usr/bin/env python
"""Run a non-cryptographic smoke test. Never use this output in the paper."""
from __future__ import annotations

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.synthetic import make_synthetic_phishing_dataset
from humanrisk_crypt.pipeline import HumanRiskCryptPipeline


def main() -> None:
    df = make_synthetic_phishing_dataset(n_samples=500, seed=42)
    pipeline = HumanRiskCryptPipeline(
        backend="mock",
        semantic_backend="hashing",
        demo_mode=True,
        seed=42,
    )
    result = pipeline.fit_evaluate(df, test_fraction=0.20)
    out_dir = ROOT / "results" / "smoke_demo"
    out_dir.mkdir(parents=True, exist_ok=True)
    result.output_frame.to_csv(out_dir / "predictions.csv", index=False)
    result.per_sample_crypto.to_csv(out_dir / "mock_crypto_trace.csv", index=False)
    (out_dir / "metrics.json").write_text(json.dumps(result.metrics, indent=2), encoding="utf-8")
    (out_dir / "split_audit.json").write_text(json.dumps(result.split_audit, indent=2), encoding="utf-8")
    (out_dir / "crypto_audit.json").write_text(json.dumps(result.encrypted_audit, indent=2), encoding="utf-8")
    print("NON-CRYPTOGRAPHIC SMOKE TEST")
    print(json.dumps(result.metrics, indent=2))
    print(json.dumps(result.encrypted_audit, indent=2))


if __name__ == "__main__":
    main()
