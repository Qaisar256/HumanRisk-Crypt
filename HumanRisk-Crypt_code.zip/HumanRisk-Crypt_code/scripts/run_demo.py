#!/usr/bin/env python
"""Run a reproducible synthetic HumanRisk Crypt demo."""
from __future__ import annotations

from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.synthetic import make_synthetic_phishing_dataset
from humanrisk_crypt.pipeline import HumanRiskCryptPipeline
from humanrisk_crypt.utils.seed import set_seed


def main() -> None:
    set_seed(42)
    df = make_synthetic_phishing_dataset(n_samples=1200, seed=42)
    pipeline = HumanRiskCryptPipeline()
    result = pipeline.fit_evaluate(df, test_size=0.25, seed=42)

    print("\nHumanRisk Crypt synthetic demo")
    print("=" * 40)
    print("Metrics:")
    for key, value in result.metrics.items():
        print(f"  {key}: {value:.3f}")
    print(f"  Latency per sample, mock BFV interface: {result.latency_ms:.3f} ms")

    out_path = ROOT / "datasets" / "synthetic" / "demo_predictions.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    result.output_frame.to_csv(out_path, index=False)
    print(f"\nSaved predictions to: {out_path}")
    print("\nExample predictions:")
    cols = ["label", "phishing_probability", "ehvss_score", "risk_label", "attack_id", "attack_name"]
    print(result.output_frame[cols].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
