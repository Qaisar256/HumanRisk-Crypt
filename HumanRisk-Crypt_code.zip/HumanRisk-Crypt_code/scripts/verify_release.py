#!/usr/bin/env python
"""Fail-fast verification of a completed paper-experiment result directory."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import yaml


def load_json(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "result_dir",
        nargs="?",
        type=Path,
        default=Path("results/paper_experiment"),
    )
    args = parser.parse_args()
    root = args.result_dir

    encrypted = load_json(root / "encrypted_audit.json")
    split = load_json(root / "split_audit.json")
    environment = load_json(root / "environment.json")
    dataset = load_json(root / "dataset_manifest.json")
    metrics = load_json(root / "metrics.json")
    config = yaml.safe_load((root / "resolved_config.yaml").read_text(encoding="utf-8"))
    trace = pd.read_csv(root / "crypto_trace.csv")
    predictions = pd.read_csv(root / "predictions.csv")

    errors: list[str] = []
    samples = int(encrypted.get("samples", -1))
    checks = {
        "real TenSEAL backend": encrypted.get("backend") == "tenseal-bfv",
        "cryptographic flag": encrypted.get("cryptographic") is True,
        "sample count is positive": samples > 0,
        "one exact output per sample": encrypted.get("exact_decryption_matches") == samples,
        "one overflow audit per sample": encrypted.get("overflow_checks_passed") == samples,
        "public evaluation context measured": encrypted.get("public_context_bytes", 0) > 0,
        "request communication measured": encrypted.get("total_request_bytes", 0) > 0,
        "response communication measured": encrypted.get("total_response_bytes", 0) > 0,
        "trace row count": len(trace) == samples,
        "prediction row count": len(predictions) == samples,
        "all trace outputs exact": bool(trace["exact_integer_match"].all()),
        "all trace modulus checks pass": bool(trace["overflow_check_passed"].all()),
        "zero domain overlap": split.get("domain_overlap") == 0,
        "strict temporal ordering": split.get("train_max_timestamp") < split.get("test_min_timestamp"),
        "paper configuration": config.get("mode") == "paper",
        "TenSEAL configured": config.get("bfv", {}).get("backend") == "tenseal",
        "no synthetic fallback": config.get("evaluation", {}).get("synthetic_fallback") is False,
        "TenSEAL package recorded": bool(environment.get("packages", {}).get("tenseal")),
        "dataset files hashed": bool(dataset.get("files")) and all(f.get("sha256") for f in dataset["files"]),
        "classification metrics present": all(k in metrics for k in ("ACC", "F1", "AUC", "LogLoss")),
    }
    for name, passed in checks.items():
        if not passed:
            errors.append(name)

    expected_total = (
        int(encrypted.get("public_context_bytes", 0))
        + int(encrypted.get("total_request_bytes", 0))
        + int(encrypted.get("total_response_bytes", 0))
    )
    if encrypted.get("total_communication_bytes_including_setup") != expected_total:
        errors.append("communication total arithmetic")

    if errors:
        raise SystemExit("Release verification failed: " + "; ".join(errors))
    print(f"Release verification passed for {samples} encrypted test samples.")


if __name__ == "__main__":
    main()
