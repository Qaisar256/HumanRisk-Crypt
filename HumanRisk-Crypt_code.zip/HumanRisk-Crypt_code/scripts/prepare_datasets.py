#!/usr/bin/env python
"""Prepare public phishing feed CSV files into a unified processed file."""
from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.loaders import load_available_datasets
from humanrisk_crypt.data.feature_extraction import FeatureBuilder, quantize_features


def main() -> None:
    df = load_available_datasets(ROOT / "datasets")
    builder = FeatureBuilder()
    x = builder.fit_transform(df)
    x_int = quantize_features(x)

    out_dir = ROOT / "datasets" / "processed"
    out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_dir / "merged_records.csv", index=False)

    import numpy as np
    np.save(out_dir / "features_quantized.npy", x_int)
    np.save(out_dir / "labels.npy", df["label"].to_numpy(dtype=int))
    print(f"Saved processed records and features to {out_dir}")


if __name__ == "__main__":
    main()
