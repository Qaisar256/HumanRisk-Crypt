#!/usr/bin/env python
"""Validate and merge real phishing feeds without fitting features."""
from __future__ import annotations

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.loaders import load_available_datasets
from humanrisk_crypt.data.splitting import time_domain_split


def main() -> None:
    df = load_available_datasets(ROOT / "datasets")
    train, test, audit = time_domain_split(df, test_fraction=0.25)
    out = ROOT / "datasets" / "processed"
    out.mkdir(parents=True, exist_ok=True)
    train.to_csv(out / "train_time_domain_disjoint.csv", index=False)
    test.to_csv(out / "test_time_domain_disjoint.csv", index=False)
    (out / "split_audit.json").write_text(json.dumps(audit.to_dict(), indent=2), encoding="utf-8")
    print(json.dumps(audit.to_dict(), indent=2))


if __name__ == "__main__":
    main()
