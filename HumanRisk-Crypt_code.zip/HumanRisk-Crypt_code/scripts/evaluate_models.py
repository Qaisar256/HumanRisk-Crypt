#!/usr/bin/env python
"""Run the paper protocol on real data with real TenSEAL BFV operations."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
from pathlib import Path
import platform
import shutil
import sys
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.crypto.bfv_interface import BFVParameters
from humanrisk_crypt.data.loaders import load_available_datasets
from humanrisk_crypt.pipeline import HumanRiskCryptPipeline
from humanrisk_crypt.utils.seed import set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "default_config.yaml")
    parser.add_argument("--dataset-root", type=Path, default=ROOT / "datasets")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "paper_experiment")
    parser.add_argument("--allow-model-download", action="store_true")
    parser.add_argument("--test-fraction", type=float, default=None)
    return parser.parse_args()


def load_paper_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")

    required_paths = [
        ("mode",),
        ("seed",),
        ("bfv", "backend"),
        ("features", "total_dim"),
        ("features", "semantic_backend"),
        ("model", "framework"),
        ("model", "optimizer"),
        ("evaluation", "split"),
        ("evaluation", "synthetic_fallback"),
    ]
    for keys in required_paths:
        node: Any = config
        for key in keys:
            if not isinstance(node, dict) or key not in node:
                raise ValueError(f"Missing configuration key: {'.'.join(keys)}")
            node = node[key]

    checks = {
        "mode": config["mode"] == "paper",
        "bfv.backend": config["bfv"]["backend"] == "tenseal",
        "features.total_dim": int(config["features"]["total_dim"]) == 1024,
        "features.semantic_backend": config["features"]["semantic_backend"] == "sentence_transformer",
        "model.framework": str(config["model"]["framework"]).lower() == "pytorch",
        "model.optimizer": str(config["model"]["optimizer"]).lower() == "adamw",
        "evaluation.split": config["evaluation"]["split"] == "time_aware_domain_disjoint",
        "evaluation.synthetic_fallback": config["evaluation"]["synthetic_fallback"] is False,
    }
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        raise ValueError(
            "Paper configuration violates required reproducibility controls: "
            + ", ".join(failed)
        )
    return config


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def dataset_manifest(dataset_root: Path, frame) -> dict[str, Any]:
    files = []
    for source in ("openphish", "phishtank", "apwg"):
        path = dataset_root / source / f"{source}.csv"
        if path.exists():
            files.append(
                {
                    "source": source,
                    "path": str(path.relative_to(dataset_root)),
                    "sha256": sha256_file(path),
                    "bytes": path.stat().st_size,
                }
            )
    labels = frame["label"].value_counts().sort_index().to_dict()
    return {
        "files": files,
        "rows": int(len(frame)),
        "class_counts": {str(int(k)): int(v) for k, v in labels.items()},
        "timestamp_min": frame["timestamp"].min().isoformat(),
        "timestamp_max": frame["timestamp"].max().isoformat(),
        "sources": {str(k): int(v) for k, v in frame["source"].value_counts().to_dict().items()},
    }


def package_version(name: str) -> str | None:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def environment_manifest() -> dict[str, Any]:
    packages = [
        "tenseal",
        "torch",
        "numpy",
        "pandas",
        "scikit-learn",
        "scipy",
        "sentence-transformers",
        "rdflib",
        "PyYAML",
    ]
    return {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "packages": {name: package_version(name) for name in packages},
        "argv": sys.argv,
    }


def main() -> None:
    args = parse_args()
    config = load_paper_config(args.config)
    seed = int(config["seed"])
    set_seed(seed)

    df = load_available_datasets(args.dataset_root)
    if config.get("ehvss", {}).get("requires_expert_calibration", False):
        if "expert_ehvss" not in df.columns:
            raise ValueError(
                "Paper configuration requires expert-calibrated E-HVSS, but the "
                "combined dataset has no 'expert_ehvss' column."
            )
        if df["expert_ehvss"].isna().any():
            raise ValueError("expert_ehvss contains missing values")

    bfv_cfg = config["bfv"]
    params = BFVParameters(
        polynomial_modulus_degree=int(bfv_cfg["polynomial_modulus_degree"]),
        coefficient_modulus_bits=tuple(int(v) for v in bfv_cfg["coefficient_modulus_bits"]),
        plaintext_modulus=int(bfv_cfg["plaintext_modulus"]),
    )
    declared_total = int(bfv_cfg.get("coefficient_modulus_total_bits", params.coefficient_modulus_total_bits))
    if declared_total != params.coefficient_modulus_total_bits:
        raise ValueError("Configured coefficient-modulus total does not equal the bit-chain sum")

    feature_cfg = config["features"]
    model_cfg = config["model"]
    model_kwargs = {
        "input_dim": int(feature_cfg["total_dim"]),
        "feature_scale": int(model_cfg["feature_scale"]),
        "weight_scale": int(model_cfg["weight_scale"]),
        "learning_rate": float(model_cfg["learning_rate"]),
        "weight_decay": float(model_cfg["weight_decay"]),
        "epochs": int(model_cfg["epochs"]),
        "batch_size": int(model_cfg["batch_size"]),
        "seed": seed,
    }
    pipeline = HumanRiskCryptPipeline(
        backend="tenseal",
        semantic_backend="sentence_transformer",
        semantic_model=str(feature_cfg["semantic_model"]),
        bfv_params=params,
        demo_mode=False,
        seed=seed,
        local_files_only=(not args.allow_model_download) and bool(feature_cfg.get("local_files_only", True)),
        model_kwargs=model_kwargs,
    )
    test_fraction = (
        float(args.test_fraction)
        if args.test_fraction is not None
        else float(config["evaluation"]["test_fraction"])
    )
    result = pipeline.fit_evaluate(df, test_fraction=test_fraction)

    args.output.mkdir(parents=True, exist_ok=True)
    result.output_frame.to_csv(args.output / "predictions.csv", index=False)
    result.per_sample_crypto.to_csv(args.output / "crypto_trace.csv", index=False)
    for name, payload in {
        "metrics.json": result.metrics,
        "split_audit.json": result.split_audit,
        "encrypted_audit.json": result.encrypted_audit,
        "dataset_manifest.json": dataset_manifest(args.dataset_root, df),
        "environment.json": environment_manifest(),
    }.items():
        (args.output / name).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    shutil.copy2(args.config, args.output / "resolved_config.yaml")
    pipeline.model.export_quantized().save(args.output / "quantized_polynomial_model.npz")
    pipeline.model.save_training_metadata(args.output / "training_metadata.json")
    pipeline.features.manifest.save(args.output / "feature_manifest.json")
    if pipeline.scorer.fitted:
        pipeline.scorer.save(args.output / "ehvss_calibration.json")

    print(json.dumps(result.metrics, indent=2))
    print(json.dumps(result.encrypted_audit, indent=2))


if __name__ == "__main__":
    main()
