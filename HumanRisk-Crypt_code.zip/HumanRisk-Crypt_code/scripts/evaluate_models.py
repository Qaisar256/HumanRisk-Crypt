#!/usr/bin/env python
"""Evaluate HumanRisk Crypt on available datasets or synthetic fallback."""
from __future__ import annotations

from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.loaders import load_available_datasets
from humanrisk_crypt.data.synthetic import make_synthetic_phishing_dataset
from humanrisk_crypt.pipeline import HumanRiskCryptPipeline
from humanrisk_crypt.evaluation.metrics import summarize_runs


def main() -> None:
    try:
        df = load_available_datasets(ROOT / "datasets")
        print("Loaded public dataset files.")
    except FileNotFoundError:
        df = make_synthetic_phishing_dataset(n_samples=1200, seed=42)
        print("No public dataset files found. Using synthetic fallback.")

    rows = []
    for seed in [42, 123, 2026]:
        result = HumanRiskCryptPipeline().fit_evaluate(df, test_size=0.25, seed=seed)
        row = result.metrics.copy()
        row["Latency"] = result.latency_ms
        rows.append(row)
        print(f"Seed {seed}: {row}")

    print("\nMean ± SD")
    print(summarize_runs(rows))


if __name__ == "__main__":
    main()
