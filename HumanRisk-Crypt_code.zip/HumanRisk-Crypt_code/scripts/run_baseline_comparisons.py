#!/usr/bin/env python
"""Run plaintext and encrypted baseline comparison tables.

This script creates the baseline comparison outputs required for the paper:
1. plaintext multimodal baselines
2. encrypted and hybrid privacy preserving baselines

Outputs are written to results/baseline_comparisons/.
"""
from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.loaders import load_available_datasets
from humanrisk_crypt.data.synthetic import make_synthetic_phishing_dataset
from humanrisk_crypt.models.baselines import (
    run_comparison_suite,
    summarize_comparison,
    format_summary_for_paper,
)


def main() -> None:
    out_dir = ROOT / "results" / "baseline_comparisons"
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        df = load_available_datasets(ROOT / "datasets")
        print("Loaded dataset files from datasets/.")
    except FileNotFoundError:
        df = make_synthetic_phishing_dataset(n_samples=1000, seed=42)
        print("No public dataset files found. Using synthetic fallback dataset.")

    seeds = [42, 123, 2026]
    plain = run_comparison_suite(df, seeds=seeds, encrypted=False)
    enc = run_comparison_suite(df, seeds=seeds, encrypted=True)
    all_results = plain.copy()
    all_results = all_results._append(enc, ignore_index=True)

    summary = summarize_comparison(all_results)
    paper_table = format_summary_for_paper(summary, proposed_only_sd=True)

    all_results.to_csv(out_dir / "all_seed_results.csv", index=False)
    summary.to_csv(out_dir / "summary_mean_sd.csv", index=False)
    paper_table.to_csv(out_dir / "paper_formatted_tables.csv", index=False)

    print("\nPaper formatted comparison table")
    print(paper_table.to_string(index=False))
    print(f"\nSaved outputs to: {out_dir}")


if __name__ == "__main__":
    main()
