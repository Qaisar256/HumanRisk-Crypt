#!/usr/bin/env python
"""Evaluate actual plaintext baselines using the paper split and features."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from humanrisk_crypt.data.loaders import load_available_datasets
from humanrisk_crypt.models.baselines import run_plaintext_baselines, summarize_comparison
from humanrisk_crypt.utils.seed import set_seed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "default_config.yaml")
    parser.add_argument("--dataset-root", type=Path, default=ROOT / "datasets")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "baselines")
    parser.add_argument("--allow-model-download", action="store_true")
    args = parser.parse_args()

    config = yaml.safe_load(args.config.read_text(encoding="utf-8"))
    if config.get("mode") != "paper" or config["evaluation"].get("synthetic_fallback") is not False:
        raise ValueError("Baselines require the validated paper configuration")
    seed = int(config["seed"])
    set_seed(seed)
    feature_cfg = config["features"]
    df = load_available_datasets(args.dataset_root)
    results, split_audit = run_plaintext_baselines(
        df,
        seeds=[seed, seed + 81, seed + 1984],
        test_fraction=float(config["evaluation"]["test_fraction"]),
        semantic_backend="sentence_transformer",
        semantic_model=str(feature_cfg["semantic_model"]),
        local_files_only=(not args.allow_model_download) and bool(feature_cfg.get("local_files_only", True)),
    )
    summary = summarize_comparison(results)
    args.output.mkdir(parents=True, exist_ok=True)
    results.to_csv(args.output / "all_seed_results.csv", index=False)
    summary.to_csv(args.output / "summary_mean_sd.csv", index=False)
    (args.output / "split_audit.json").write_text(json.dumps(split_audit, indent=2), encoding="utf-8")
    shutil.copy2(args.config, args.output / "resolved_config.yaml")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
