# Baseline comparison protocol

This document describes the baseline comparison code added for reproducibility.

## Data flow

1. Load CSV files from `datasets/` when available.
2. Fall back to the synthetic phishing dataset when public feeds are not present.
3. Split data using stratified train and test partitions for each seed.
4. Build fixed dimensional features with the shared `FeatureBuilder`.
5. Train each baseline model.
6. Evaluate ACC, PRE, REC, F1, AUC, FPR, FNR, Log Loss, and latency.
7. Save all seed level results and mean ± standard deviation summaries.

## Feature groups

* URL only: URL length, digits, dots, hyphens, slashes, IP like pattern, entropy.
* Lexical: same lexical URL features.
* URL + DOM: URL features plus behavioral metadata and categorical indicators.
* Text only: persuasion scores and categorical semantic indicators.
* Fusion: all lexical, behavioral, persuasion, and metadata features.

## Important note

The default encrypted baselines use a mock BFV backend for runnable open code.
This is intended for interface and reproducibility testing. For cryptographic
results, plug in Microsoft SEAL or a compatible BFV wrapper through
`humanrisk_crypt.crypto.bfv_interface`.
