# Baseline comparison protocol

All plaintext baselines use the same 1,024-dimensional feature representation and the same fixed time-aware, domain-disjoint split. Multiple random seeds affect model initialization, not the test-set composition.

The repository reports only models it actually trains and executes. It does not label scikit-learn estimators as encrypted models. It does not assign latency floors. The proposed encrypted model is evaluated separately through `scripts/evaluate_models.py`, where cryptographic stage times and serialized ciphertext sizes are measured directly.
