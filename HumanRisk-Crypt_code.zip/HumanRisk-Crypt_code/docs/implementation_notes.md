# Cryptographic implementation notes

BFV evaluates exact modular integer arithmetic. HumanRisk-Crypt therefore quantizes the normalized feature vector and learned polynomial coefficients into signed integers. Before encryption, the implementation computes a conservative absolute bound for the complete polynomial. The run is rejected when that bound is not below half of the plaintext modulus, because centered signed decoding could otherwise wrap modulo `t`.

The circuit has multiplicative depth one. It computes an elementwise ciphertext square, two encrypted-plain dot products, and an addition with the integer bias. TenSEAL automatically uses Microsoft SEAL evaluation keys for the required multiplication and rotations. The public server context contains public, Galois, and relinearization keys but not the secret key.

The decrypted integer logit is divided by the model weight scale. Sigmoid is applied by the data owner after decryption. This keeps the encrypted circuit shallow and avoids falsely describing a non-polynomial sigmoid as a BFV operation.

Serialized request and response sizes are measured from the exact ciphertext objects transmitted through the simulated client/server boundary. The public/evaluation context, which excludes the secret key, is measured as a one-time setup transfer. The audit reports per-request sizes, total traffic including setup, and the setup cost amortized across the evaluated samples.

TenSEAL releases expose different portions of the lower-level SEAL API. The code attempts to read `invariant_noise_budget` through the linked decryptor. When unavailable, the trace records a null value. Exact decryption verification and modulus-bound checking still remain mandatory.
