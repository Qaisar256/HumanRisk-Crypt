# Implementation Notes

## BFV interface

The provided implementation uses `MockBFVContext` for testing and reproducibility. It implements the same high-level methods expected from a real BFV backend:

- `encode(vector)`
- `encrypt(plaintext)`
- `decrypt(ciphertext)`
- `add(a, b)`
- `multiply(a, b)`
- `matmul(matrix, ciphertext, bias)`

For real encrypted inference, replace `MockBFVContext` with a Microsoft SEAL or TenSEAL wrapper.

## Parameter setting

Default BFV parameters follow the manuscript configuration:

- Polynomial modulus degree: 8192
- Coefficient modulus chain: approximately 218 bits
- Plaintext modulus: 65537

The approximate uncompressed BFV ciphertext size is computed in `BFVParameters`.

## Quadratic polynomial approximation

The model uses a quadratic residual transform:

`P(x) = alpha0 + alpha1*x + alpha2*x^2`

This approximates nonlinear activation while maintaining shallow multiplicative depth.

## E-HVSS

E-HVSS scores combine susceptibility, exploitability, detectability, and impact into a 0 to 10 score. The demo uses interpretable heuristic component functions. For the final paper, these weights and component functions should be calibrated against expert severity ratings.
