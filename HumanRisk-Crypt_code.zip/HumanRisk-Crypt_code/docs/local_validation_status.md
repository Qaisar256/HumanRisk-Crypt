# Local validation status

The corrected repository was checked in the available development runtime using:

```bash
python -m pytest -q
python scripts/run_demo.py
```

Observed test status: **5 passed and 1 skipped**. The skipped test is the real TenSEAL public-context quadratic-circuit integration test. This development runtime uses Python 3.13 and does not contain a compatible TenSEAL package. The non-cryptographic smoke test completed, verified exact integer-circuit equality for every tested sample, and reported no suspicious perfect classification result.

No real-paper metric or cryptographic latency is included in the repository. The authorized OpenPhish, PhishTank, and APWG files were not available in this runtime. A reportable experiment must be run in the supplied Python 3.11 Docker environment with the authorized datasets, then checked with:

```bash
python scripts/verify_release.py results/paper_experiment
```

The verifier rejects mock results, temporal or domain overlap, missing dataset hashes, non-exact BFV outputs, failed plaintext-modulus bounds, missing TenSEAL provenance, and inconsistent communication totals.
