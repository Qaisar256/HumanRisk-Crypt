# Reviewer 3 implementation remediation

## 1. Real BFV inference

`humanrisk_crypt.crypto.bfv_interface.TenSEALBFVContext` creates a genuine BFV context through TenSEAL, which is built on Microsoft SEAL. The client serializes a context without the secret key for server evaluation. The server evaluates an integer quadratic circuit over a BFV ciphertext.

`MockBFVContext` remains only for unit tests and smoke demonstrations. The main experiment script cannot select it.

## 2. Measured latency and communication

All latency floors have been deleted. `HumanRiskCryptPipeline._infer_one` times encoding/encryption, request serialization, server deserialization, homomorphic evaluation, response serialization, client deserialization, and decryption with `perf_counter`. The pipeline separately measures client context/key setup, public-context serialization, and server-context loading. Ciphertext communication is measured from the actual serialized byte strings, and the audit reports both per-request traffic and total communication including the one-time public/evaluation context.

Each encrypted output is checked against the corresponding plaintext integer circuit. A modulus-bound audit runs before encryption. Noise budget is recorded when the installed TenSEAL binding exposes Microsoft SEAL's invariant-noise-budget method. An unavailable noise-budget value remains `null`; it is never estimated or invented.

## 3. Dataset and leakage control

Paper scripts require real CSV files and terminate when they are absent. Synthetic fallback has been removed from all paper and baseline experiment scripts.

`time_domain_split` creates a chronological test partition and removes from training every earlier record belonging to a test domain. The generated audit reports temporal boundaries, domain counts, removed rows, and zero overlap.

The synthetic generator now samples a latent risk variable first. The observed features and label are sampled independently conditional on that latent variable. No feature is generated from the realized label. Synthetic output remains restricted to smoke testing.

## 4. Feature and model consistency

The feature pipeline returns exactly 1,024 values:

- 512 local SentenceTransformer semantic values
- 512 structured URL and metadata hashing values

Paper mode uses `sentence-transformers/distiluse-base-multilingual-cased-v2`, which is checked at runtime for a 512-dimensional output. A deterministic hashing semantic backend exists only in demo mode.

The classifier is implemented in PyTorch and trained using AdamW. It learns linear and elementwise quadratic coefficients, then exports an integer BFV circuit. Configuration and training metadata are saved with each run. The experiment also records dataset file hashes, class and source counts, runtime package versions, and the exact resolved YAML configuration.

## 5. System-component scope

RDFLib/SPARQL ontology lookup and expert calibration for E-HVSS are implemented. The repository does not pretend to implement searchable encryption, attribute-based encryption, multi-key FHE, or encrypted deep/federated baselines. The README identifies those items as unsupported by this release. Corresponding manuscript claims should be removed or moved to future work unless separate implementations are provided.
