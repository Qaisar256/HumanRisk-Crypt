from humanrisk_crypt.data.synthetic import make_synthetic_phishing_dataset
from humanrisk_crypt.pipeline import HumanRiskCryptPipeline


def test_pipeline_runs():
    df = make_synthetic_phishing_dataset(n_samples=100, seed=1)
    result = HumanRiskCryptPipeline().fit_evaluate(df, test_size=0.25, seed=1)
    assert "ACC" in result.metrics
    assert len(result.output_frame) == 25
    assert "ehvss_score" in result.output_frame.columns
