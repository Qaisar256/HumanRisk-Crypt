from __future__ import annotations

import numpy as np
import pytest
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

from humanrisk_crypt.crypto.bfv_interface import BFVParameters, TenSEALBFVContext, TenSEALUnavailableError
from humanrisk_crypt.data.feature_extraction import FeatureBuilder
from humanrisk_crypt.data.splitting import time_domain_split
from humanrisk_crypt.data.synthetic import make_synthetic_phishing_dataset
from humanrisk_crypt.pipeline import HumanRiskCryptPipeline
from humanrisk_crypt.models.polynomial_model import (
    PolynomialSurrogateClassifier,
    QuantizedPolynomialParameters,
)


def test_feature_vector_is_1024_dimensions():
    df = make_synthetic_phishing_dataset(n_samples=24, seed=7)
    builder = FeatureBuilder(semantic_backend="hashing")
    x = builder.fit_transform(df)
    assert x.shape == (24, 1024)
    assert np.isfinite(x).all()


def test_time_domain_split_has_no_leakage():
    df = make_synthetic_phishing_dataset(n_samples=240, seed=5)
    train, test, audit = time_domain_split(df, test_fraction=0.2)
    assert audit.domain_overlap == 0
    assert set(train.registered_domain).isdisjoint(set(test.registered_domain))
    assert train.timestamp.max() < test.timestamp.min()


def test_synthetic_data_is_not_perfectly_separable():
    df = make_synthetic_phishing_dataset(n_samples=700, seed=11)
    train, test, _ = time_domain_split(df, test_fraction=0.2)
    builder = FeatureBuilder(semantic_backend="hashing")
    x_train = builder.fit_transform(train)
    x_test = builder.transform(test)
    model = LogisticRegression(max_iter=1000).fit(x_train, train.label)
    auc = roc_auc_score(test.label, model.predict_proba(x_test)[:, 1])
    assert auc < 0.98


def test_mock_pipeline_runs_and_audits_exact_integer_results():
    df = make_synthetic_phishing_dataset(n_samples=180, seed=3)
    pipeline = HumanRiskCryptPipeline(
        backend="mock",
        semantic_backend="hashing",
        demo_mode=True,
        seed=3,
    )
    pipeline.model.epochs = 20
    result = pipeline.fit_evaluate(df, test_fraction=0.2)
    assert "ACC" in result.metrics
    assert result.encrypted_audit["cryptographic"] is False
    assert result.encrypted_audit["exact_decryption_matches"] == len(result.output_frame)
    assert result.encrypted_audit["overflow_checks_passed"] == len(result.output_frame)
    assert (result.per_sample_crypto["request_bytes"] > 0).all()


def test_paper_mode_rejects_mock_backend():
    with pytest.raises(ValueError):
        HumanRiskCryptPipeline(backend="mock", semantic_backend="hashing", demo_mode=False)


def test_real_bfv_quadratic_public_context_when_tenseal_is_available():
    try:
        client = TenSEALBFVContext(BFVParameters())
    except TenSEALUnavailableError:
        pytest.skip("TenSEAL is not installed in this test environment")

    server = TenSEALBFVContext.from_public_context_bytes(
        client.public_context_bytes(), BFVParameters()
    )
    values = np.array([1, -2, 3, -4], dtype=np.int64)
    params = QuantizedPolynomialParameters(
        linear_weight=np.array([2, -1, 3, 1], dtype=np.int64),
        quadratic_weight=np.array([1, 2, -1, 1], dtype=np.int64),
        bias=7,
        feature_scale=1,
        weight_scale=1,
    )
    request = client.serialize_ciphertext(client.encrypt_vector(values))
    server_ct = server.deserialize_ciphertext(request)
    result_ct = PolynomialSurrogateClassifier.encrypted_integer_logit(server_ct, params)
    response = server.serialize_ciphertext(result_ct)
    observed = int(client.decrypt_vector(client.deserialize_ciphertext(response))[0])
    expected = PolynomialSurrogateClassifier.plaintext_integer_logit(values, params)
    assert observed == expected
