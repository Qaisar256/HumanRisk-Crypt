# Dataset folders

Place dataset files here:

- `openphish/openphish.csv`
- `phishtank/phishtank.csv`
- `apwg/apwg.csv`

Expected minimum column:

- `label`: 1 for phishing, 0 for benign

Recommended columns:

- `url`
- `html_text`
- `brand`
- `sector`
- `domain_age_days`
- `hosting_stability`
- `urgency_score`
- `authority_score`
- `reward_score`
- `fear_score`

The demo pipeline can run without these files using synthetic data.
