# Authorized phishing datasets

Place authorized exports at:

- `openphish/openphish.csv`
- `phishtank/phishtank.csv`
- `apwg/apwg.csv`

Required columns:

- `url`
- `label`, with 1 for phishing and 0 for benign
- `timestamp`, the observation or collection time

Recommended detection columns:

- `html_text`
- `registered_domain`, preferably a validated public-suffix-aware value
- `brand`
- `sector`
- `domain_age_days`
- `hosting_stability`
- `urgency_score`
- `authority_score`
- `reward_score`
- `fear_score`

The full E-HVSS experiment also requires `expert_ehvss` in the range 0 to 10. `expert_id` is optional but recommended for expert-level audit. When `registered_domain` is absent, the loader derives it with the pinned tldextract bundled suffix-list snapshot and never downloads a live list.

Paper experiment scripts do not fall back to synthetic data.
