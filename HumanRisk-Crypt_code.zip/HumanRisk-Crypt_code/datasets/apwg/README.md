# Authorized phishing datasets

Place authorized exports at:

- `openphish/openphish.csv`
- `phishtank/phishtank.csv`
- `apwg/apwg.csv`

Required columns:

- `url`
- `label`, with 1 for phishing and 0 for benign
- `timestamp`, the observation or collection time

Recommended columns:

- `html_text`
- `registered_domain`
- `brand`
- `sector`
- `domain_age_days`
- `hosting_stability`
- `urgency_score`
- `authority_score`
- `reward_score`
- `fear_score`
- `expert_ehvss`
- `expert_id`

Paper experiment scripts do not fall back to synthetic data.
