# Synthetic smoke-test data

Synthetic data is generated only by `scripts/run_demo.py`. It is intended to test software flow and is not used by paper experiment scripts. No synthetic metric should be placed in a manuscript table as evidence for phishing-detection performance.
